let manualTradeTrigger = false;
let ignoreNextProposal = false;
window.addEventListener('load', function() {
    let ws, rnd, spot, spotArr, timeArr, spotClose, timeClose, digitClose, high, low, open, time, dps, xd, digit, cnt, id, lng, chart, chart2, chart3, b;
    let dps2, xVal2, yVal2, dps3;
    let supportLevels = [],
        resistanceLevels = [];
    let reversalSignal = null,
        directionSignal = null;
    let counter = 1;
    let lastSignal = null;
    let stripLines = [];
    let stripLinesTail = [];
    let stripLinesHead = [];
    const levelThreshold = 5;
    let resistanceLevelsCandle = [],
        supportLevelsCandle = [];
    let tailSupportResistance = [];
    let reversalSignalCandle = null,
        directionSignalCandle = null;
    let counterCandle = 1;
    let lastSignalCandle = null;
    let indexLabelDirection = "";
    let indexLabelColor = "";
    let largeLoop = true;
    const str = ["R_100", "R_10", "R_25", "R_50", "R_75", "RDBEAR", "RDBULL"];
    dps = [];
    dps2 = [];
    dps3 = [];
    time = [0];
    spot = [0];
    spotArr = [0];
    timeArr = [0];
    digit = [0];
    cnt = 1306; // 20 Spot Prices Window
    lng = "EN";
    mColor = "";
    mType = "";
    mSize = 1;
    timeClose = [0];
    spotClose = [0];
    digitClose = [0];
    xVal2 = [0];
    yVal2 = [0];
    high = [0];
    low = [0];
    open = [0];
    digit = [0];
    cntQuotes = 30;
    QuotesSinput = 100;
    var duraSymbol = "t",
        currency = "USD",
        isloading = true,
        starting_balance = 0,
        connected = false,
        currencySymbol = "$",
        tradeInProgress = false,
        crAccount = "",
        tkNo = "",
        tokenInput = "",
        tradeNumber = 0;
    var proposal_id, lgcode, cntrid;
    var s_prop = 0,
        e_prop = 0,
        slines = [],
        isbuy = false,
        b_start = null,
        ix = 0,
        oc = -2,
        barrier = 0,
        exitSpot = "";
    let balance_Disp, profit = 0,
        balance_now = "", stakeinp_rise = "";
    let AutoTradeToggle = false;
    let MinTickDura = 1;
    let orderPlaced = true;
    let runOnce = true;
    let currentDate = new Date();
    var ldpOption = '';
    
   
    const sockets = [], balances = {}, profits = {}, tradeRows = {}, connectedFlags = {}, mirroredOrders = {}, preTradeBalances = {};
    
    const TOKENS = [];
    let expectedSellCount = 0;
    let sellCount = 0;
    let allowAutoTrade = false;

    let useIndividualPercent = false;
    let globalPercent = 100;

    // AUTO-STAKE CALCULATION
    let calculatedStake;

    // ============================
    // Utility: Export to CSV
    // ============================
    function exportTableToCSV(index) {
        
        const table = document.querySelector(`#table_${index}`);
        if (!table) return;
    
        const rows = Array.from(table.querySelectorAll("tr"));
        const csv = rows.map((row, rowIdx) => {
            return Array.from(row.querySelectorAll("th, td")).map((cell, colIdx) => {
                let val = cell.textContent.trim();

                if (rowIdx !== 0 && (colIdx === 5 || colIdx === 7)) {
                    let num = parseFloat(val);
                    val = isNaN(num) ? val : num.toFixed(2);
                }
    
                return `"${val}"`;
            }).join(",");
        }).join("\n");
    
        const accountLabel = TOKENS[index]?.label?.replace(/\s+/g, "_") || `Account_${index + 1}`;
    
        const now = new Date();
        const timestamp = now.toISOString().replace(/[:T]/g, "_").slice(0, 19);
    
        const filename = `${accountLabel}_Trade_${timestamp}.csv`;
    
        const blob = new Blob([csv], { type: "text/csv" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        link.click();
        
    }

    ///Purcharche synch Token
    document.getElementById("stakeOptionTxt").textContent =  "Increment Stake %";
    const tokenInputs = document.getElementById("tokenInputs");
    const saved = JSON.parse(localStorage.getItem("config_tokens") || "[]");
    if (saved.length === 0) {
        tokenInputs.appendChild(createTokenEntry("Token 1", "", true, true));
    } else {
        saved.forEach((entry, i) => {
            const masked = entry.masked || sessionStorage.getItem("cr_account_" + i) || "";
            tokenInputs.appendChild(createTokenEntry(`Token ${i + 1}`, entry.token, entry.save, entry.active, masked));
        });
    }

    // Token Management
    function createTokenEntry(labelText = "", tokenValue = "", save = false, active = true, masked = "") {
        const container = document.createElement("div");
        container.className = "token-entry";

        const label = document.createElement("span");
        label.textContent = labelText;
        label.className = "token-label";

        const maskedSpan = document.createElement("span");
        maskedSpan.className = "masked-account2";
        if (masked) maskedSpan.textContent = ` (${masked})`;

        const input = document.createElement("input");
        input.type = "text";
        input.placeholder = labelText;
        input.className = "token-input";
        input.value = tokenValue;

        const saveBox = document.createElement("input");
        saveBox.type = "checkbox";
        saveBox.checked = save;
        saveBox.title = "Save";
        saveBox.className = "token-save";

        const activeBox = document.createElement("input");
        activeBox.type = "checkbox";
        activeBox.checked = active;
        activeBox.title = "Active";
        activeBox.className = "token-active";

        const removeBtn = document.createElement("button");
        removeBtn.textContent = "✖";
        removeBtn.className = "remove-token-btn";

        //Full cleanup on click
        removeBtn.onclick = () => {
            const idx = Array.from(document.querySelectorAll(".token-entry")).indexOf(container);
          
            // Disconnect socket if connected
            if (connectedFlags[idx]) {
                if (sockets[idx] && sockets[idx].readyState === WebSocket.OPEN) {
                    sockets[idx].close();
                }
          
                const accountTable = document.querySelector(`#table_${idx}`)?.closest(".account");
                if (accountTable) accountTable.remove();
            
                delete sockets[idx];
                delete connectedFlags[idx];
                delete tradeRows[idx];
                delete profits[idx];
                delete balances[idx];
            
                //console.log(`Removed Account ${idx + 1} and disconnected`);
            }
          
            // Remove from localStorage if it was marked "Save"
            const saveCheckbox = container.querySelector(".token-save");
            const inputToken = container.querySelector(".token-input").value.trim();
            if (!saveCheckbox.checked && inputToken) {
                const saved = JSON.parse(localStorage.getItem("config_tokens") || "[]");
                const filtered = saved.filter((entry) => entry.token !== inputToken);
                localStorage.setItem("config_tokens", JSON.stringify(filtered));
            }
          
            // Remove token entry from the DOM
            container.remove();
        };

        // Append all elements
        container.appendChild(label);
        container.appendChild(maskedSpan);
        container.appendChild(input);
        container.appendChild(document.createTextNode(" Save: "));
        container.appendChild(saveBox);
        container.appendChild(document.createTextNode(" Active: "));
        container.appendChild(activeBox);
        container.appendChild(removeBtn);
        return container;
    }

    // ============================
    // Token Entry + Sync Button
    // ============================
    document.getElementById("addTokenBtn").addEventListener("click", () => {
        const count = document.querySelectorAll(".token-input").length + 1;
        const newEntry = createTokenEntry(`Token ${count}`);
        document.getElementById("tokenInputs").appendChild(newEntry);
    });

    document.getElementById("startSyncBtn").addEventListener("click", () => {
        TOKENS.length = 0;
        document.getElementById("accountsPanel").innerHTML = "";

        const saveConfig = [];
        const seenTokens = new Set();

        document.querySelectorAll(".token-entry").forEach((entry, i) => {
            const input = entry.querySelector(".token-input");
            const token = input.value.trim();
            const save = entry.querySelector(".token-save").checked;
            const active = entry.querySelector(".token-active").checked;

            if (token && !seenTokens.has(token)) {
                seenTokens.add(token);
                if (save) {
                    const masked = sessionStorage.getItem("cr_account_" + i) || "";
                    saveConfig.push({
                        token,
                        save,
                        active,
                        masked
                    });
                }
                if (active) TOKENS.push({
                    id: token,
                    label: `Account ${i + 1}`
                });
                
            } 
            
        });

        if (saveConfig.length > 0) localStorage.setItem("config_tokens", JSON.stringify(saveConfig));
        else localStorage.removeItem("config_tokens");

        TOKENS.forEach((token, index) => initAccount(token, index));

    });

    //////////Amount
    const individual_Global_Toggle = document.getElementById("useIndividualPercent");
    individual_Global_Toggle.addEventListener("change", updatePercentInputs);
    
    individual_Global_Toggle.addEventListener("change",updateStakeInputs);

    const globalPercentInput = document.getElementById("globalPercentInput");
    globalPercentInput.addEventListener("input", updateStakeInputs);

    const stakeOption = document.getElementById("stakeOption");
    const stakeOptionTxt = document.getElementById("stakeOptionTxt");
    stakeOption.addEventListener("change", function() {
        if (stakeOption.checked == true) {
            document.getElementById("useIndividualPercentLbl").style.marginLeft = "-149px";
            stakeOptionTxt.textContent =  "Fix Stake %";
        } else {
            document.getElementById("useIndividualPercentLbl").style.marginLeft = "-180px";
            stakeOptionTxt.textContent = "Increment Stake %";
        }
    })


    /////////
    // ============================
    // Account UI + Socket Handling
    // ============================
    function initAccount(token, index) {
        const container = document.createElement("div");
        const useIndividualPercent = document.getElementById("useIndividualPercent").checked;
        let div_visibility = "visible";
        if (useIndividualPercent) {
            div_visibility = "visible";
        } else {
            div_visibility = "hidden";
        }
        container.className = "account";
        container.innerHTML = `
            <h2 id="label_${index}">${token.label}</h2>
            <div class="token-controls">
                <button class="connect-toggle disconnected" id="toggleConnect_${index}">Connect</button>
                <button id="saveCSV_${index}">💾 Save to CSV</button>
            </div>
            <div>
                <div id="percentInputDiv_${index}" style="visibility: ${div_visibility};">
                    Stake Percentage: <input type="number" id="percentInput_${index}" value="5" style="width:50px;">%
                </div>  
                Stake: $ <input type="number" id="stakeInput_${index}" value="0.00" style="width:80px;">
            </div>
            <div id="statusLine_${index}" class="status-header">🔴 Disconnected | Balance: 0.00 | P/L: 0.00</div>
            <table id="table_${index}" class="mirror-table"><thead><tr>
                <th>#</th><th>Time</th><th>Type</th><th>Ref ID</th><th>Symbol</th><th>Amount</th><th>Barrier</th><th>Result</th>
            </tr></thead><tbody></tbody></table>
            <div id="error_${index}" class="error-msg"></div>
        `;

        //Create and insert a visual divider (before the account)
        const divider = document.createElement('div');
        divider.className = 'account-divider';
        document.getElementById("accountsPanel").appendChild(divider);
        
        document.getElementById("accountsPanel").appendChild(container);
        document.getElementById(`toggleConnect_${index}`).onclick = () => {
            if (connectedFlags[index]) { sockets[index].close(); connectedFlags[index] = false; }
            else connectSocket(index);
        };
        
        //Connect toggle
        document.getElementById(`toggleConnect_${index}`).onclick = () => {
            if (connectedFlags[index]) {
                sockets[index].close();
                updateStatus(index, false, "Disconnected");
                connectedFlags[index] = false;
            } else {
                connectSocket(index);
            }
        };

        document.getElementById(`percentInput_${index}`).addEventListener("input", () => {
            if (document.getElementById("useIndividualPercent").checked) {
                // Use individual percentage per token
                const individualPercentage = parseFloat(document.getElementById(`percentInput_${index}`).value) / 100 ;
                calculatedStake = (balances[index] * individualPercentage).toFixed(2);
                // Update stake field for the token row
                document.getElementById(`stakeInput_${index}`).value = calculatedStake;
            }
        });

        document.getElementById(`stakeInput_${index}`).addEventListener("input", () => {
            if (document.getElementById("useIndividualPercent").checked) {
                // Use individual percentage per token
                const individualPercentage = parseFloat(document.getElementById(`stakeInput_${index}`).value) /balances[index] ;
                calculatedStake = (individualPercentage * 100).toFixed(2);
                // Update stake field for the token row
                document.getElementById(`percentInput_${index}`).value = calculatedStake;
            }
        });

        //CSV Export button
        document.getElementById(`saveCSV_${index}`).addEventListener("click", () => {
            exportTableToCSV(index);
        });
       
        connectSocket(index);
    }

    function connectSocket(index) {
        const token = TOKENS[index];
        const ws = new WebSocket("wss://ws.binaryws.com/websockets/v3?app_id=11&l=" + lng);
        sockets[index] = ws;
        ws.onopen = () => {
            ws.send(JSON.stringify({ authorize: token.id }));
            connectedFlags[index] = true;
        };
        ws.onmessage = (e) => handleMessage(JSON.parse(e.data), index);
        setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ ping: 1 })); }, 25000);
    }
    
    // ============================
    // Message Routing
    // ============================
    function handleMessage(msg, index) {
        if (msg.error) return showError(index, msg.error.message);
    
        if (msg.msg_type === 'authorize') return handleAuth(msg, index);
        if (msg.msg_type === 'transaction') return handleTransaction(msg.transaction, index);
        if (msg.msg_type === 'buy') return handleBuy(msg.buy, index);
        
        //When proposal arrives, send buy — but don't add UI row yet
        if (msg.msg_type === 'proposal' && mirroredOrders[index]) {
            const order = mirroredOrders[index];
            const buyPayload = {
                buy: msg.proposal.id,
                price: order.amount
            };
    
            sockets[index].send(JSON.stringify(buyPayload));
            //console.log("Sent BUY for", TOKENS[index].label, buyPayload, order);
            //console.log("Sent BUY for index:",index);
            mirroredOrders[index] = {
                ...order,
                contractId: msg.proposal.id  //Optional: for tracking
            };
        }
    }
    
    function handleAuth(msg, index) {
        updateStatus(index, true, "Connected");
        balances[index] = msg.authorize.balance;
        profits[index] = 0;
        updatePLUI(index);
    
        const rawAccount = msg.authorize.loginid || "";
        const masked = rawAccount.slice(0, 7) + "*****";
        //const masked = rawAccount;
        sessionStorage.setItem("cr_account_" + index, masked);
        TOKENS[index].maskedId = masked;
    
        //Ensure only the main sync table <h3> gets updated
        const labelEl = document.querySelector(`#label_${index}`);
        if (labelEl && !labelEl.textContent.includes("*****")) {
            labelEl.textContent += ` (${masked})`;
        }
    
        sockets[index].send(JSON.stringify({ transaction: 1, subscribe: 1 }));
        updateStakeInputs();
    }
    
    ///////Stake and percentage update
    function updateStakeInputs() {
        TOKENS.forEach((_, index) => {
            if (document.getElementById("useIndividualPercent").checked) {
                // Use individual percentage per token
                const individualPercentage = parseFloat(document.getElementById(`percentInput_${index}`).value) / 100 || 0.05;
                calculatedStake = (balances[index] * individualPercentage).toFixed(2);
                
            } else {
                // Use global percentage
                const globalPercentage = parseFloat(document.getElementById("globalPercentInput").value) / 100;
                const referenceBalance = balances[index]; // Pick one token as reference
                const multiplier = parseFloat(document.getElementById("globalPercentInput").value) || 1;
                //calculatedStake = (referenceBalance * globalPercentage * multiplier).toFixed(2);
                calculatedStake = (referenceBalance * globalPercentage).toFixed(2);

            }
            // Update stake field for the token row
            document.getElementById(`stakeInput_${index}`).value = calculatedStake;
        })
    }

    

    function handleTransaction(t, index) {
        //console.log("mirroredOrders: ",mirroredOrders)
        if (t.action === 'sell') {
            const tradeMap = tradeRows[index];
            console.log(tradeMap)
            
            if (document.getElementById("stakeOption").checked == false) {
                updateStakeInputs();
            }
            if (tradeMap && tradeMap[t.contract_id]) {
                const { row } = tradeMap[t.contract_id];
    
                // Use updated balance logic if available
                const preBalance = preTradeBalances[index] || 0;
                const postBalance = t.balance || balances[index] || 0;
                const result = (postBalance - preBalance).toFixed(2);
    
                row.cells[7].textContent = result;
                row.cells[7].style.color = result >= 0 ? "lightgreen" : "red";
    
                profits[index] += parseFloat(result);
                updatePLUI(index);
    
                // Clean up to avoid stale balance usage
                delete preTradeBalances[index];
                balances[index] = t.balance;

                sellCount++;

                if (sellCount >= expectedSellCount) {
                    //console.debug("[CLEANUP] All sell responses received, clearing mirroredOrders");
                    Object.keys(mirroredOrders).forEach(key => delete mirroredOrders[key]);
                    sellCount = 0;
                    expectedSellCount = 0;
                }
            } else {
                console.warn("Sell received, but no matching contract ID for token", index, t.contract_id);
            }
        }
    }

    function handleBuy(buyMsg, index) {
        const payload = mirroredOrders[index];
        if (!payload || !buyMsg.contract_id) return;
    
        preTradeBalances[index] = balances[index]; //Store balance before trade

        //const tradeMap = tradeRows[index] || {};
        const row = addRow(index, {
            transaction_time: Date.now() / 1000,
            contract_id: buyMsg.transaction_id,
            symbol: payload.proposalParams.symbol,
            amount: payload.amount,
            barrier: payload.proposalParams.barrier || "-",
            contract_type: payload.proposalParams.contract_type
        }, payload.sourceType || "mirror");
      
        tradeRows[index] = tradeRows[index] || {};
        tradeRows[index][buyMsg.contract_id] = { row, amount: payload.amount };

        expectedSellCount = Object.keys(mirroredOrders).length;
        sellCount = 0;
        
    }

    function mirrorTrade(payload, sourceType, originIndex = -1) {
        const buy_price = payload.amount || 1;
        TOKENS.forEach((token, i) => {
            if (connectedFlags[i] && i !== originIndex) {
                try {
                    const ws = sockets[i];
                    const amountStake = parseFloat(document.getElementById(`stakeInput_${i}`).value);
                    const proposalPayload = {
                        proposal: 1,
                        //amount: buy_price,
                        amount: amountStake,
                        basis: payload.basis || "stake",
                        contract_type: payload.contract_type,
                        symbol: payload.symbol,
                        duration: payload.duration,
                        currency: payload.currency || "USD",
                        duration_unit: payload.duration_unit || "t"
                    };
    
                    if (payload.barrier) {
                        proposalPayload.barrier = payload.barrier;
                    }
    
                    ws.send(JSON.stringify(proposalPayload));
                    //console.log("Sent proposal for", token.label, proposalPayload);
    
                    //Store for use when proposal response arrives
                    mirroredOrders[i] = {
                        proposalParams: proposalPayload,
                        sourceType,
                        //amount: buy_price
                        amount: amountStake,
                    };
                } catch (err) {
                    showError(i, "Trade Error: " + err.message);
                    //console.error("Mirror trade proposal failed for token", i, err);
                }
            }
        });
    }

    ////Amount
    function updatePercentInputs() {
        const useIndividualPercent = document.getElementById("useIndividualPercent").checked;
        const global_Percentage  = document.getElementById("global_Percentage");
       
        if (useIndividualPercent) {           
            global_Percentage.style.visibility = "hidden";
            TOKENS.forEach((token, idx) => {
                const percentInputDiv = document.getElementById(`percentInputDiv_${idx}`);
                percentInputDiv.style.visibility = "visible";
            });       
        } else {
            global_Percentage.style.visibility = "visible";
            //Trying to auto refresh stake of individual account
            TOKENS.forEach((token, idx) => {
                const percentInputDiv = document.getElementById(`percentInputDiv_${idx}`);
                percentInputDiv.style.visibility = "hidden";
            });   
        }
    }
    
    function addRow(index, t, source) {
        const table = document.querySelector(`#table_${index} tbody`);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${table.children.length + 1}</td>
            <td>${new Date(t.transaction_time * 1000).toLocaleTimeString()}</td>
            <td>${source}</td>
            <td>${t.contract_id || "-"}</td>
            <td>${t.symbol}</td>
            <td>${parseFloat(t.amount).toFixed(2)}</td>
            <td>${t.barrier || '-'}</td>
            <td>-</td>
        `;
        table.insertBefore(row, table.firstChild);
        return row;
    }
    
    function updateStatus(index, ok, msg) {
        const el = document.getElementById(`statusLine_${index}`);
        const btn = document.getElementById(`toggleConnect_${index}`);
        const balance = balances[index]?.toFixed(2) || "0.00";
        const pl = profits[index]?.toFixed(2) || "0.00";
        el.textContent = `${ok ? '🟢' : '🔴'} ${msg} | Balance: ${balance} | P/L: ${pl}`;
        if (btn) {
            btn.textContent = ok ? "Disconnect" : "Connect";
            btn.className = ok ? "connect-toggle connected" : "connect-toggle disconnected";
        }
    }
    
    function updatePLUI(index) {
        updateStatus(index, connectedFlags[index] || false, connectedFlags[index] ? "Connected" : "Disconnected");
    }

    function showError(index, msg) {
        document.getElementById(`error_${index}`).textContent = msg;
    }
    

    /*
    document.addEventListener("DOMContentLoaded", () => {
        TOKENS.forEach((token, index) => initAccount(token, index));
    });
    */
    ////////////////////////////


    function checkSliderPosition() {
        const currentTime = new Date(currentDate.getTime());
        const sliderMin = (chart3.sessionVariables._axisXMin);
        const sliderMax = (chart3.sessionVariables._axisXMax);
        let sliderDiff = (sliderMax - sliderMin);
        if (sliderMax) {
            if (sliderMax >= currentTime) {
                chart3.options.navigator.slider.maximum = new Date(time[0] * 1000);
                chart3.options.navigator.slider.minimum = new Date((time[0] * 1000) - sliderDiff);
                chart3.render();
            }
        }
    }
    ///Purchase codes
    document.getElementById("tokenbtn").addEventListener("click", function() {
        tkInput = document.getElementById("token");
        if (document.getElementById("token").value !== "") {
            auThorized(document.getElementById("token").value)
            tkNo = document.getElementById("token").value;         
            tradeLoad(tkNo);
        } else {
            auThorized("empty");
            tkNo = "";
        }
    });

    function updateTimeGmt() {
        const now = new Date();
        const hours = now.getUTCHours().toString().padStart(2, '0');
        const minutes = now.getUTCMinutes().toString().padStart(2, '0');
        const seconds = now.getUTCSeconds().toString().padStart(2, '0');
        document.getElementById('timeGmt').textContent = `${hours}:${minutes}:${seconds} GMT`;
    }
    updateTimeGmt();
    setInterval(updateTimeGmt, 1000);
    //////////////////
    var tokIdSec = crAccount.substring(7, 20);

    function toggleDigit(d, m) {
        var nameClass = document.querySelector("#digits > span:nth-child(" + d + ")").className;
        if (nameClass != "digits_moved_" + m) {
            document.querySelector("#digits > span:nth-child(" + d + ")").classList.remove(nameClass);
            document.querySelector("#digits > span:nth-child(" + d + ")").classList.add("digits_moved_" + m);
        }
    }

    function toggleHead(e, s) {
        var nameClass = document.querySelector("#headcol > span:nth-child(" + e + ")").className;
        if (nameClass != "Head_moved_" + s) {
            document.querySelector("#headcol > span:nth-child(" + e + ")").classList.remove(nameClass);
            document.querySelector("#headcol > span:nth-child(" + e + ")").classList.add("Head_moved_" + s);
        }
    }
    ////Save Token
    var stCheck = document.getElementById("SaveTk"),
        tokenInput = document.getElementById("token");
    ///chrome extension
    try {
        chrome.storage.sync.get(['tokcheckbox'], function(items) {
            if (items.tokcheckbox && items.tokcheckbox !== "") {
                stCheck.setAttribute("checked", "checked");
                chrome.storage.sync.get(['tokId'], function(items2) {
                    tokenInput.value = items2.tokId;
                });
            } else {
                stCheck.removeAttribute("checked");
                tokenInput.value = "";
            }
        });
        document.getElementById("SaveTk").addEventListener("change", function() {
            if (this.checked && tokenInput.value !== "") {
                chrome.storage.sync.set({
                    'tokId': tokenInput.value
                });
                chrome.storage.sync.set({
                    'tokcheckbox': stCheck.value
                });
            } else {
                chrome.storage.sync.set({
                    'tokId': ''
                });
                chrome.storage.sync.set({
                    'tokcheckbox': ''
                });
            }
        });
        ///Outside browser
    } catch (e) {
        if (localStorage.tokcheckbox && localStorage.tokcheckbox !== "") {
            stCheck.setAttribute("checked", "checked");
            tokenInput.value = localStorage['tokId' + tokIdSec];
        } else {
            stCheck.removeAttribute("checked");
            tokenInput.value = "";
        }
        document.getElementById("SaveTk").addEventListener("change", function() {
            if (this.checked && tokenInput.value !== "") {
                localStorage['tokId' + tokIdSec] = tokenInput.value;
                localStorage.tokcheckbox = stCheck.value;
            } else {
                localStorage['tokId' + tokIdSec] = "";
                localStorage.tokcheckbox = "";
            }
        });
    }

    function blinKIputToken(Message, dispMsg) {
        //console.log("error")
        if (tokenInput.value !== "") {
            //console.log("token not empty")
            if (Message == "invalidTkn") {
                document.getElementById("token").classList.remove("inputClss")
                document.getElementById("token").classList.add("blinkToken-bg");
                setTimeout(BlinkClassRemove, 2000);

                function BlinkClassRemove() {
                    document.getElementById("token").classList.remove("blinkToken-bg");
                    document.getElementById("token").value = ""

                    function writeTokenInput(dispMsg) {
                        if (dispMsg == "Token invalid...") {
                            document.getElementById("token").classList.add("error-bg");
                            document.getElementById("token").placeholder = dispMsg;
                            setTimeout(removeError, 2000);

                            function removeError() {
                                document.getElementById("token").classList.remove("error-bg");
                                document.getElementById("token").classList.add("inputClss");
                                document.getElementById("token").placeholder = "Enter token id...";
                            }
                        }
                    }
                    writeTokenInput(dispMsg);
                }
            }
            if (Message == "Log") {
                document.getElementById("tokenbtn").classList.remove("inputClss");
                document.getElementById("tokenbtn").classList.add("blinkTokenBtn-bg");
                setTimeout(BlinkClassRemove, 2000);

                function BlinkClassRemove() {
                    document.getElementById("tokenbtn").classList.remove("blinkTokenBtn-bg");
                    document.getElementById("tokenbtn").classList.add("inputClss");
                }
            }
        }
        if (tokenInput.value === "") {
            //console.log("token empty ")
            if (Message == "Log" || Message !== "Log") {
                //console.log("token Log")
                document.getElementById("token").classList.remove("inputClss");
                document.getElementById("token").classList.add("blinkToken-bg");
                setTimeout(BlinkClassRemove, 2000);

                function BlinkClassRemove() {
                    document.getElementById("token").classList.remove("blinkToken-bg");
                    document.getElementById("token").classList.add("inputClss");

                    function writeTokenInput(dispMsg) {
                        if (dispMsg == "Enter token id...") {
                            document.getElementById("token").classList.remove("inputClss");
                            document.getElementById("token").placeholder = dispMsg;
                            document.getElementById("token").classList.add("error-bg");
                            setTimeout(removeError, 2000);

                            function removeError() {
                                document.getElementById("token").placeholder = "Enter token id...";
                                document.getElementById("token").classList.remove("error-bg");
                                document.getElementById("token").classList.add("inputClss");
                            }
                        }
                    }
                    writeTokenInput(dispMsg);
                }
            }
        }
    }
    //Hide balance
    var BalHide = document.getElementById("lsBalHide");
    BalHide.addEventListener("change", function() {
        if (this.checked) {
            document.getElementById("displayBal").innerHTML = currencySymbol + " " + "**********";
        } else {
            if (balance_Disp == 0 || balance_Disp == undefined) {
                document.getElementById("displayBal").innerHTML = currencySymbol + " " + "0.00";
            } else {
                document.getElementById("displayBal").innerHTML = currencySymbol + " " + balance_Disp;
            }
        }
    });
    var HdCol = new Array(20);
    HdClss = new Array(20);
    digCol = new Array(20);

    function clearHd() {
        HdClss = new Array(20);
        HdCol = new Array(20);
        for (var e = 1; e < 20; e++) {
            toggleHead(e, e);
        }
    }
    rndMenu = document.querySelectorAll('div.menu > span');
    for (var i = 0; i < rndMenu.length; i++) {
        clickMenu(rndMenu[i]);
    }

    function toggleMenu(data) {
        for (var i = 0; i < rndMenu.length; i++) {
            rndMenu[i].classList.remove('menu-active');
        }
        data.classList.add('menu-active');
    }

    function clickMenu(data) {
        data.addEventListener('click', function() {
            toggleMenu(data);
        });
    }

    function rndGet() {
        random = document.querySelector("body > div.menu > span.menu-active").title;
        switch (random) {
            case str[0]:
                rnd = "R_100";
                xd = 2;
                break;
            case str[1]:
                rnd = "R_10";
                xd = 3;
                break;
            case str[2]:
                rnd = "R_25";
                xd = 3;
                break;
            case str[3]:
                rnd = "R_50";
                xd = 4;
                break;
            case str[4]:
                rnd = "R_75";
                xd = 4;
                break;
            case str[5]:
                rnd = "RDBEAR";
                xd = 4;
                break;
            case str[6]:
                rnd = "RDBULL";
                xd = 4;
                break;
            case str[7]:
                rnd = "1HZ100V";
                xd = 2;
                break;
            case str[8]:
                rnd = "1HZ10V";
                xd = 2;
                break;
            case str[9]:
                rnd = "1HZ25V";
                xd = 2;
                break;
            case str[10]:
                rnd = "1HZ50V";
                xd = 2;
                break;
            case str[11]:
                rnd = "1HZ75V";
                xd = 2;
                break;
            default:
                rnd = "R";
                xd = 0;
                break;
        }
    }
    rndGet();
    ws = new WebSocket("wss://ws.binaryws.com/websockets/v3?app_id=11&l=" + lng);
    ///Purchase codes
    output = document.getElementById("output");
    var timestamp = ''
    //////////////////
    ///Purchase codes connect
    function auThorized(token) {
        timestamp = getTimeFixed(new Date());
        ws.send(JSON.stringify({
            authorize: token
        }));
    }
    ws.onopen = function() {
        ws.send(JSON.stringify({
            ticks: rnd
        }));
        ws.send(JSON.stringify({
            contracts_for: rnd,
            currency: currency
        }));
    };
    ///Purchase codes Time
    function getTimeFixed(m) {
        return m.getHours() + ":" + m.getMinutes() + ":" + (m.getSeconds()).toLocaleString('en-US', {
            minimumIntegerDigits: 2,
            useGrouping: false
        });
    }

    function clearTable() {
        var Table = document.getElementById("tbTrade");
        Table.innerHTML = "";
    }

    function directionTable(i, TimeTr, DetailsTr) {
        let iStrt = i.toString();
        let numOfTrade = '<span class="" style=" table-layout: fixed; width: 100%; color:white" title="">' + iStrt + '</span>';
        document.getElementById("tbTrade").innerHTML += '<tr id = "line' + i + '" </tr>';
        document.getElementById("line" + iStrt).innerHTML += '<td id = "Time' + i + '" align="center" style="width:18%; height: 2px;"></td>';
        document.getElementById("line" + iStrt).innerHTML += '<td id = "Details' + i + '" align="center" style="width:34%; height: 2px;"></td>';
        document.getElementById("line" + iStrt).innerHTML += '<td id = "Entry' + i + '" align="center" style="width:14%; height: 2px;"></td>';
        document.getElementById("line" + iStrt).innerHTML += '<td id = "Exit' + i + '" align="center" style="width:14%; height: 2px;"></td>';
        document.getElementById("line" + iStrt).innerHTML += '<td id = "Results' + i + '" align="center" style="width:20%; height: 2px;"></td>';
        document.getElementById("Time" + iStrt).innerHTML = TimeTr;
        document.getElementById("Details" + iStrt).innerHTML = DetailsTr;
    }

    function entryTable(i, Entry) {
        let iStrt = i.toString();
        document.getElementById("Entry" + iStrt).innerHTML = Entry;
    }

    function resultTable(i, Results, Exit) {
        let iStrt = i.toString();
        document.getElementById("Exit" + iStrt).innerHTML = Exit;
        document.getElementById("Results" + iStrt).innerHTML = Results;
    }
    ws.onmessage = function(msg) {
        b = JSON.parse(msg.data);
        //console.log('b: ',b)
        if (b.tick) {
            rndGet();
            if (b.echo_req.ticks === rnd) {
                id = b.tick.id;
                ws.send(JSON.stringify({
                    ticks_history: rnd,
                    end: "latest",
                    start: 1,
                    style: "candles",
                    count: cntQuotes + 1
                }));
                ws.send(JSON.stringify({
                    ticks_history: rnd,
                    end: "latest",
                    start: 1,
                    style: "ticks",
                    count: cnt + 1
                }));
            } else {
                ws.send(JSON.stringify({
                    forget: id
                }));
                ws.send(JSON.stringify({
                    forget_all: "ticks"
                }));
                ws.send(JSON.stringify({
                    forget_all: "candles"
                }));
                ws.send(JSON.stringify({
                    ticks: rnd
                }));
                largeLoop = true;
                clearHd();
            }
        }
        /////////////////Candle
        if (b.echo_req) {
            if (b.echo_req.ticks_history == rnd) {
                if (b.candles) {
                    for (let i = 0; i < cntQuotes + 1; i++) {
                        timeClose[i] = b.candles[cntQuotes - i].epoch;
                        high[i] = b.candles[cntQuotes - i].high;
                        high[i] = parseFloat(high[i]).toFixed(xd);
                        low[i] = b.candles[cntQuotes - i].low;
                        low[i] = parseFloat(low[i]).toFixed(xd);
                        open[i] = b.candles[cntQuotes - i].open;
                        open[i] = parseFloat(open[i]).toFixed(xd);
                        spotClose[i] = b.candles[cntQuotes - i].close;
                        spotClose[i] = parseFloat(spotClose[i]).toFixed(xd);
                        digitClose[i] = spotClose[i].slice(-1);
                    }
                    let resistanceCandle = false;
                    let supportCandle = false;
                    resistanceLevelsCandle = [];
                    supportLevelsCandle = [];
                    for (let i = 0; i < cntQuotes + 1; i++) {
                        if (i < cntQuotes) {
                            xVal2 = new Date(timeClose[i] * 1000);
                            yVal2 = [parseFloat(open[i]), parseFloat(high[i]), parseFloat(low[i]), parseFloat(spotClose[i])];
                            if (high[i] > high[i - 1] && high[i] > high[i + 1] && (high[i + 1] > high[i + 2] && high[i - 1] > high[i - 2])) {
                                //resistanceLevelsCandle.push({ index: i, value: high[i], time: xVal2[i] });
                                let isDistinct = resistanceLevelsCandle.every(level => Math.abs(level - high[i]) > levelThreshold);
                                if (isDistinct) {
                                    resistanceLevelsCandle.push({
                                        index: i,
                                        value: high[i]
                                    });
                                }
                                if (!resistanceCandle) {
                                    //indexLabelDirection = "⇧";
                                    //indexLabelColor = "#29abe2";
                                    //resistanceCandle = true;
                                }
                            } else if (low[i] < low[i - 1] && low[i] < low[i + 1] && (low[i + 1] < low[i + 2] && low[i - 1] < low[i - 2])) {
                                //supportLevelsCandle.push({ index: i, value: low[i], time: xVal2[i]});
                                let isDistinct = supportLevelsCandle.every(level => Math.abs(level - low[i]) > levelThreshold);
                                if (isDistinct) {
                                    supportLevelsCandle.push({
                                        index: i,
                                        value: low[i]
                                    });
                                }
                                if (!supportCandle) {
                                    //indexLabelDirection = "⇩";
                                    //indexLabelColor = "#c03";
                                    //supportCandle = true;
                                }
                            }
                        }
                        dps2.push({
                            x: xVal2,
                            y: yVal2,
                            indexLabel: indexLabelDirection,
                            indexLabelFontWeight: "bold",
                            indexLabelFontSize: 16,
                            indexLabelFontColor: indexLabelColor,
                            color: open[i] < close[i] ? "green" : "red"
                        })
                    }
                    // Add resistance lines
                    resistanceLevelsCandle.forEach(level => {
                        stripLines.push({
                            value: level.value,
                            color: "#29abe2",
                            thickness: 1,
                            //label: `Resistance ${level.value}`,
                            labelFontSize: 10,
                            labelFontColor: "#29abe2"
                        });
                    });
                    // Add support lines
                    supportLevelsCandle.forEach(level => {
                        stripLines.push({
                            value: level.value,
                            color: "#c03",
                            thickness: 1,
                            //label: `Support ${level.value}`,
                            labelFontSize: 10,
                            labelFontColor: "#c03"
                        });
                    });
                    if (dps2.length > cntQuotes + 1) {
                        while (dps2.length != cntQuotes + 1) {
                            dps2.shift();
                        }
                    }
                    //render
                    // chart2.options.axisY.stripLines[0].value  =  spotClose[0];
                    changeBorderColor(chart2);
                    chart2.render();

                    function changeBorderColor(chart) {
                        var dataSeries;
                        for (var i = 0; i < chart.options.data.length; i++) {
                            dataSeries = chart.options.data[i];
                            for (var j = 0; j < dataSeries.dataPoints.length; j++) {
                                dataSeries.dataPoints[j].color = (dataSeries.dataPoints[j].y[0] <= dataSeries.dataPoints[j].y[3]) ? (dataSeries.risingColor ? dataSeries.risingColor : dataSeries.color) : (dataSeries.fallingColor ? dataSeries.fallingColor : dataSeries.color);
                            }
                        }
                    }
                };
            };
        };
        ////////////////

        let readyHistory = largeLoop ? b.history : b.tick;
        let readyTicksHistory = largeLoop ? b.echo_req.ticks_history : b.echo_req.ticks;

        if (readyHistory && readyTicksHistory === rnd) {
            if (largeLoop) {
                let timeNew = [];
                for (let i = 0; i < cnt + 1; i++) {
                    if (i < 20) {
                        timeNew[i] = parseFloat(b.history.times[cnt - i]).toFixed(xd);
                    }
                }

                if (timeNew[0] === time[0]) {
                    console.log("Arrays are duplicate");
                } else {
                    for (let i = 0; i < cnt; i++) {
                        if (i < 20) {
                            time[i] = parseFloat(b.history.times[cnt - i]);
                            spot[i] = parseFloat(b.history.prices[cnt - i]).toFixed(xd);
                            digit[i] = spot[i].slice(-1);
                        }
                        spotArr[i] = parseFloat(b.history.prices[cnt - i]).toFixed(xd);
                        timeArr[i] = parseFloat(b.history.times[cnt - i]).toFixed(xd);

                        if (i === cnt) {
                            largeLoop = false;
                        }
                    }
                }
            } else {
                spot.pop();
                spot.unshift(parseFloat(b.tick.quote).toFixed(xd));
                spotArr.pop();
                spotArr.unshift(parseFloat(b.tick.quote).toFixed(xd));
                timeArr.pop();
                timeArr.unshift(b.tick.epoch);
                digit.pop();
                digit.unshift(parseFloat(b.tick.quote).toFixed(xd).slice(-1));
                time.pop();
                time.unshift(parseFloat(b.tick.epoch));
            }

            checkPatterns();
            checkPatternsCandle();


            let barrier_Input_Value = document.getElementById("barrier_Input");
            if (barrier_Input_Value) {
                let inBarrierText = document.getElementById("inBarrier");
                if (inBarrierText) {
                    inBarrierText.textContent = 'Indicative barrier: ' + (parseFloat(barrier_Input_Value.value) + parseFloat(spot[0])).toFixed(xd);
                }
            }


            for (var i = spot.length - 1; i >= 0; i--) {
                if (spot[i] > spot[i + 1]) {
                    toggleDigit(20 - i, "Up");
                    digCol[i] = "b";
                }
                if (spot[i] < spot[i + 1]) {
                    toggleDigit(20 - i, "Down");
                    digCol[i] = "r";
                }
                if (spot[i] == spot[i + 1]) {
                    if (digCol[i + 1] == "b") {
                        toggleDigit(20 - i, "Up");
                        digCol[i] = "b";
                    } else if (digCol[i + 1] == "r") {
                        toggleDigit(20 - i, "Down");
                        digCol[i] = "r";
                    }
                }
            }

            for (var i = 0; i < spot.length + 1; i++) {
                var SpotCalc = spotArr.slice(i, i + 20);
                if (parseFloat(spotArr[i]) == Math.max.apply(null, SpotCalc)) {
                    HdCol[i] = "up";
                } else if (parseFloat(spotArr[i]) == Math.min.apply(null, SpotCalc)) {
                    HdCol[i] = "down";
                } else {
                    HdCol[i] = "mid";
                }
            }

            let maxMarked = false;
            let minMarked = false;
            supportLevels = [], resistanceLevels = [];
            tailSupportResistance = [];
            document.getElementById("spot").innerHTML = spot[0];
            if (spot[1] < spot[0]) {
                document.getElementById("spot").style = 'background-color:#16C79A;'
            }
            if (spot[1] > spot[0]) {
                document.getElementById("spot").style = 'background-color:#D80032;'

            } else if (spot[1] == spot[0]) {
                if (spot[2] < spot[1]) {
                    document.getElementById("spot").style = 'background-color:#16C79A;'
                } else if (spot[2] > spot[1]) {
                    document.getElementById("spot").style = 'background-color:#D80032;'
                }
            }
            for (let i = 0; i < 20; i++) {
                let xVal = new Date(time[i] * 1000);
                let yVal = parseFloat(spot[i]);

                //5  - 10 tick
                if (i >= 10 && i <= 15) {
                    if (spot[i] > spot[i - 1] && spot[i] > spot[i + 1]) {
                        tailSupportResistance.push({
                            index: i,
                            value: yVal,
                            time: xVal
                        });
                    }
                    if (spot[i] < spot[i - 1] && spot[i] < spot[i + 1]) {
                        tailSupportResistance.push({
                            index: i,
                            value: yVal,
                            time: xVal
                        });
                    }
                }

                if (spot[i] > spot[i - 1] && spot[i] > spot[i + 1]) {
                    resistanceLevels.push({
                        index: i,
                        value: yVal,
                        time: xVal
                    });
                } else if (spot[i] < spot[i - 1] && spot[i] < spot[i + 1]) {
                    supportLevels.push({
                        index: i,
                        value: yVal,
                        time: xVal
                    });
                }
                if (yVal == Math.max.apply(null, spot) && !maxMarked) {
                    mColor = "#1439ff";
                    mSize = 5;
                    mType = "circle";
                    maxMarked = true;
                } else if (yVal == Math.min.apply(null, spot) && !minMarked) {
                    mColor = "#ff1439";
                    mSize = 5;
                    mType = "circle";
                    minMarked = true;
                } else if (i == 0) {
                    mColor = "#32cd32";
                    mSize = 5;
                    mType = "circle";
                } else {
                    mType = "none"
                    mSize = 2;
                    //mType= "circle";
                    mColor = "#ffff";
                }

                dps.push({
                    x: xVal,
                    y: yVal,
                    markerColor: mColor,
                    markerType: mType,
                    markerSize: mSize
                });



            }

            for (let i = 0; i < cnt; i++) {
                let xVal3 = new Date(timeArr[i] * 1000);
                let yVal3 = parseFloat(spotArr[i]);
                dps3.push({
                    x: xVal3,
                    y: yVal3,
                });
            }

            if (dps.length > 20) {
                while (dps.length != 20) {
                    dps.shift();
                }
            }
            if (dps3.length > cnt) {
                while (dps3.length != cnt) {
                    dps3.shift();
                }
            }



            /*
            document.body.addEventListener('change', function(e) {
                if (e.target) {
                    console.log("e.target.id: ", e.target.id);
                }
            })
            */

            const eventsToTrace = ['click', 'change', 'input', 'submit'];
            eventsToTrace.forEach(eventType => {
                if (!window[`__debug_${eventType}`]) {
                    document.body.addEventListener(eventType, e => {
                        //console.log(`[DEBUG] ${eventType.toUpperCase()} on:`, e.target.id || e.target.className || e.target.tagName);
                    }, true); // Capture phase
                    window[`__debug_${eventType}`] = true;
                }
            });

            const addEventOriginal = EventTarget.prototype.addEventListener;
            EventTarget.prototype.addEventListener = function (type, listener, options) {
                //console.log(`[BIND] ${type} listener on`, this.id || this.className || this.tagName);
                addEventOriginal.call(this, type, listener, options);
            };



            let minX = (chart3.sessionVariables._axisXMin);
            let maxX = (chart3.sessionVariables._axisXMax);
            let filteredData = dps3.filter(dp => dp.x >= minX && dp.x <= maxX);
            if (filteredData.length > 0) {
                let minY = Math.min(...filteredData.map(dp => dp.y));
                let maxY = Math.max(...filteredData.map(dp => dp.y));
                let unit = 1;
                maxY = Math.ceil(maxY / unit) * unit;
                minY = Math.floor(minY / unit) * unit;

                let range = maxX - minX;
                let yInterval;
                if (range <= 390000) {
                    yInterval = 1;
                } else {
                    yInterval = 2;
                }

                Object.assign(chart3.options.charts[0].axisY, {
                    minimum: minY,
                    maximum: maxY,
                    interval: yInterval
                });
                chart3.render();
            }


            chart3.options.charts[0].axisY.stripLines[0].value = spotArr[0];;

            const sliderMin = (chart3.sessionVariables._axisXMin);
            const sliderMax = (chart3.sessionVariables._axisXMax);
            const sliderDiff = (sliderMax - sliderMin)
            if (sliderMax) {
                chart3.options.navigator.slider.maximum = new Date(sliderMax);
                chart3.options.navigator.slider.minimum = new Date(sliderMin);
            }

            /*
            if (sliderDiff < 12000){
                chart3.options.navigator.slider.maximum = new Date(time[0]*1000);      
                chart3.options.navigator.slider.minimum = new Date((time[0]*1000) - 12000); 
            }
            */


            //chart.options.axisY.stripLines[0].value  =  spot[0];
            checkSliderPosition();
            chart.render();
            chart3.render();

            ///Purchase codes
            if (isloading) {
                //document.getElementById("preloadingtxt").style.display = "none";
                //console.log('---DONE--')
                isloading = false

                if (connected == true) {
                    setTimeout(function() {
                        tokenInput = document.getElementById("token");
                        if (document.getElementById("token").value !== "") {
                            auThorized(document.getElementById("token").value);
                        } else {
                            auThorized("empty")

                        }

                    }, 1000);
                }
            }
            //////////////////

            for (var i = 1; i < 20 + 1; i++) {
                document.querySelector("#headcol > span:nth-child(" + i + ")").innerHTML = digit[20 - i];
                document.querySelector("#digits > span:nth-child(" + i + ")").innerHTML = digit[20 - i];
                toggleHead(i, HdCol[20 - i]);
            }

            function checkPatterns() {
                let currentSignal = "";
                let directionSignal = "";

                //stripLinesHead = [];
                const currentPrice = parseFloat(spotClose[0]);
                const currenttime = new Date(time[0] * 1000);

                //console.log("Current Price:", currentPrice);

                // Analyze support levels
                if (supportLevels.length >= 1) {
                    const lastSupport = supportLevels[0];

                    // Detect breakout below support
                    if (currentPrice < lastSupport.value) {
                        currentSignal = " Breakout Below Support";
                        directionSignal = "Down";
                        //console.log("Breakout below support detected!");
                        stripLinesHead.push({
                            x: lastSupport.time,
                            y: lastSupport.value,
                            markerType: "none",
                            lineColor: "red"
                        });
                        stripLinesHead.push({
                            x: currenttime,
                            y: currentPrice,
                            markerType: "none",
                            lineColor: "red"
                        });
                    }

                    // Detect support reversal (requires at least 2 levels)
                    if (supportLevels.length >= 2) {
                        const secondLastSupport = supportLevels[1];
                        //console.log("Second Last Support:", secondLastSupport.value);

                        if (lastSupport.value > secondLastSupport.value) {
                            currentSignal = " Upward Reversal (Support)";
                            directionSignal = "Up";
                            //console.log("Upward support reversal detected!");
                            stripLinesHead.push({
                                x: lastSupport.time,
                                y: lastSupport.value,
                                markerType: "none",
                                lineColor: "blue"
                            });
                            stripLinesHead.push({
                                x: currenttime,
                                y: currentPrice,
                                markerType: "none",
                                lineColor: "blue"
                            });
                        } else if (lastSupport.value < secondLastSupport.value) {
                            currentSignal = " Downward Reversal (Support)";
                            directionSignal = "Down";
                            //console.log("Downward support reversal detected!");
                            stripLinesHead.push({
                                x: lastSupport.time,
                                y: lastSupport.value,
                                markerType: "none",
                                lineColor: "red"
                            });
                            stripLinesHead.push({
                                x: currenttime,
                                y: currentPrice,
                                markerType: "none",
                                lineColor: "red"
                            });
                        }
                    }
                } else {
                    //console.warn("Not enough  data for support levels.");
                }

                //stripLinesSupRes
                // Analyze resistance levels
                if (resistanceLevels.length >= 1) {
                    const lastResistance = resistanceLevels[0];
                    //console.log("Last Resistance:", lastResistance.value);

                    // Detect breakout above resistance
                    if (currentPrice > lastResistance.value) {
                        currentSignal = " Breakout Above Resistance";
                        directionSignal = "Up";
                        //console.log("Breakout above resistance detected!");
                        stripLinesHead.push({
                            x: lastResistance.time,
                            y: lastResistance.value,
                            markerType: "none",
                            lineColor: "blue"
                        });
                        stripLinesHead.push({
                            x: currenttime,
                            y: currentPrice,
                            markerType: "none",
                            lineColor: "blue"
                        });
                    }

                    // Detect resistance reversal (requires at least 2 levels)
                    if (resistanceLevels.length >= 2) {
                        const secondLastResistance = resistanceLevels[1];
                        //console.log("Second Last Resistance:", secondLastResistance.value);

                        if (lastResistance.value < secondLastResistance.value) {
                            currentSignal = " Downward Reversal (Resistance)";
                            directionSignal = "Down";
                            stripLinesHead.push({
                                x: lastResistance.time,
                                y: lastResistance.value,
                                markerType: "none",
                                lineColor: "red"
                            });
                            stripLinesHead.push({
                                x: currenttime,
                                y: currentPrice,
                                markerType: "none",
                                lineColor: "red"
                            });
                            //console.log("Downward resistance reversal detected!");
                        } else if (lastResistance.value > secondLastResistance.value) {
                            currentSignal = " Upward Reversal (Resistance)";
                            directionSignal = "Up";
                            //console.log("Upward resistance reversal detected!");
                            stripLinesHead.push({
                                x: lastResistance.time,
                                y: lastResistance.value,
                                markerType: "none",
                                lineColor: "blue"
                            });
                            stripLinesHead.push({
                                x: currenttime,
                                y: currentPrice,
                                markerType: "none",
                                lineColor: "blue"
                            });
                        }
                    }
                } else {
                    //console.warn("Not enough  data for resistance levels.");
                }

                // If no signal was detected
                if (currentSignal === "") {
                    currentSignal = "Continuation";
                    directionSignal = "Flat";
                    //console.log("No significant signal detected. Continuation.");
                }

                // Update the signal count
                if (currentSignal === lastSignal) {
                    counter++;
                } else {
                    counter = 1;
                    lastSignal = currentSignal;
                }

                if (stripLinesHead.length > 2) {
                    while (stripLinesHead.length != 2) {
                        stripLinesHead.shift();
                    }
                }
                // Display the result
                showResult(currentSignal, directionSignal);
            }


            function showResult(signal, direction) {
                //const resultBox = document.getElementById("resultBox");
                const showResult = document.getElementById("showResult");
                if (!showResult) return;
                showResult.innerHTML = `<h3>${counter}. Spot ${signal} - ${direction}</h3>`;
                showResult.style.color =
                    direction === "Up" ? "blue" :
                    direction === "Down" ? "red" :
                    direction === "Flat" ? "grenn" :
                    "gray";
            }

            ///Tail spot market/////////////////

            //stripLinesTail
            function detectTailLineChart(spot, time) {

                let currentSignal = "";
                let directionSignal = "";
                const lastPrice = parseFloat(spot[spot.length - 3]);
                const lastTime = new Date(time[time.length - 3] * 1000);
                if (tailSupportResistance.length >= 1) {
                    const firstSupportResistance = tailSupportResistance[tailSupportResistance.length - 1];
                    //const firstSupportResistance = tailSupportResistance[0];
                    // Detect tail pressure with 5 - 10 tick from the tail   
                    if (lastPrice > firstSupportResistance.value) {
                        currentSignal = "Tail Pressure";
                        directionSignal = "Down";
                        //console.log("Pressure Down detected!");
                        stripLinesTail.push({
                            x: lastTime,
                            y: lastPrice,
                            markerType: "none",
                            lineColor: "red"
                        });
                        stripLinesTail.push({
                            x: firstSupportResistance.time,
                            y: firstSupportResistance.value,
                            markerType: "none",
                            lineColor: "red"
                        });
                    } else if (lastPrice < firstSupportResistance.value) {
                        currentSignal = "Tail Pressure";
                        directionSignal = "Up";
                        //console.log("Pressure Up detected!");
                        stripLinesTail.push({
                            x: lastTime,
                            y: lastPrice,
                            markerType: "none",
                            lineColor: "blue"
                        });
                        stripLinesTail.push({
                            x: firstSupportResistance.time,
                            y: firstSupportResistance.value,
                            markerType: "none",
                            lineColor: "blue"
                        });
                    }


                    if (stripLinesTail.length > 2) {
                        while (stripLinesTail.length != 2) {
                            stripLinesTail.shift();
                        }
                    }
                }
                // Display the result
                showPressureResult(currentSignal, directionSignal);
            }

            function showPressureResult(signal, direction) {
                //const resultBox = document.getElementById("resultBox");
                const tailPressureResult = document.getElementById("tailPressureResult");
                const candleTail = document.getElementById("candleTail");
                candleTail.innerHTML = `<h3> ---</h3>`
                if (!tailPressureResult) return;
                tailPressureResult.innerHTML = `<h3> ${signal} - ${direction}</h3>`;
                tailPressureResult.style.color =
                    direction === "Up" ? "blue" :
                    direction === "Down" ? "red" :
                    "gray";
            }

            detectTailLineChart(spot, time)

            ///Trend spot market///////////////////////
            function detectTrendLineChart(spotPrices) {

                const currentPrice = spotPrices[0];
                const lastPrice = spotPrices[spotPrices.length - 1];
                const midPrice = spotPrices[Math.floor(spotPrices.length / 2)];

                let trend = "";

                // Determine the trend using simple criteria
                if (currentPrice > midPrice && midPrice > lastPrice) {
                    trend = "Upward";
                } else if (currentPrice < midPrice && midPrice < lastPrice) {
                    trend = "Downward";
                } else {
                    trend = "Consolidation";
                }

                //console.log("Worm Current Trend:", trend);
                updateSpotTrend(trend)
                //return { trend, currentPrice, midPrice, lastPrice };
            }


            detectTrendLineChart(spot);


            ////////////////////
            /*
            function calculateMovingAverage(prices, period) {
                if (prices.length < period) return null;

                let sum = 0;
                for (let i = 0; i < period; i++) {
                    sum += prices[i];
                }
                return sum / period;
            }

            function detectTrendLineChart(spotPrices) {
                spotPrices = spotPrices.map(Number);
                const shortTermMA = calculateMovingAverage(spotPrices, 5);
                const longTermMA = calculateMovingAverage(spotPrices, 20);

                if (!shortTermMA || !longTermMA) {
                    console.error("Not enough data for moving average trend detection.");
                    return null;
                }

                let trend = "";
                if (shortTermMA > longTermMA) {
                    trend = "Upward";
                } else if (shortTermMA < longTermMA) {
                    trend = "Downward";
                } else {
                    trend = "Consolidation";
                }

                console.log("Short-Term MA:", shortTermMA);
                console.log("Long-Term MA:", longTermMA);
                console.log("Trend:", trend);

                updateSpotTrend(trend)
                return trend;
            }

            */

            function updateSpotTrend(trend) {
                const spotTrend = document.getElementById("spotTrend");
                spotTrend.textContent = `Spot Trend: ${trend}`;
                spotTrend.style.color =
                    trend === "Upward" ? "blue" :
                    trend === "Downward" ? "red" :
                    trend === "Consolidation" ? "green" :
                    "gray";
            }
            ////////////////////

            function checkPatternsCandle() {
                let currentSignalCandle = "";
                let directionSignalCandle = "";

                const currentPriceCandle = parseFloat(spotClose[0]);

                // Analyze support levels
                if (supportLevelsCandle.length >= 1) {
                    const lastSupportCandle = supportLevelsCandle[0];
                    //console.log("Last Support:", lastSupportCandle.value);

                    // Detect breakout below support
                    if (currentPriceCandle < lastSupportCandle.value) {
                        currentSignalCandle = "Candle Breakout Below Support";
                        directionSignalCandle = "Down";
                        //console.log("Breakout below support detected!");
                    }

                    // Detect support reversal (requires at least 2 levels)
                    if (supportLevelsCandle.length >= 2) {
                        const secondLastSupportCandle = supportLevelsCandle[1];
                        //console.log("Second Last Support:", secondLastSupportCandle.value);

                        if (lastSupportCandle.value > secondLastSupportCandle.value) {
                            currentSignalCandle = "Candle Upward Reversal (Support)";
                            directionSignalCandle = "Up";
                            //console.log("Upward support reversal detected!");
                        } else if (lastSupportCandle.value < secondLastSupportCandle.value) {
                            currentSignalCandle = "Candle Downward Reversal (Support)";
                            directionSignalCandle = "Down";
                            //console.log("Downward support reversal detected!");
                        }
                    }
                } else {
                    //console.warn("Not enough Candle data for support levels.");
                }

                // Analyze resistance levels
                if (resistanceLevelsCandle.length >= 1) {
                    const lastResistanceCandle = resistanceLevelsCandle[0];
                    //console.log("Last Resistance:", lastResistanceCandle.value);

                    // Detect breakout above resistance
                    if (currentPriceCandle > lastResistanceCandle.value) {
                        currentSignalCandle = "Candle Breakout Above Resistance";
                        directionSignalCandle = "Up";
                        //console.log("Breakout above resistance detected!");
                    }

                    // Detect resistance reversal (requires at least 2 levels)
                    if (resistanceLevelsCandle.length >= 2) {
                        const secondLastResistanceCandle = resistanceLevelsCandle[1];
                        //console.log("Second Last Resistance:", secondLastResistanceCandle.value);

                        if (lastResistanceCandle.value < secondLastResistanceCandle.value) {
                            currentSignalCandle = "Candle Downward Reversal (Resistance)";
                            directionSignalCandle = "Down";
                            //console.log("Downward resistance reversal detected!");
                        } else if (lastResistanceCandle.value > secondLastResistanceCandle.value) {
                            currentSignalCandle = "Candle Upward Reversal (Resistance)";
                            directionSignalCandle = "Up";
                            //console.log("Upward resistance reversal detected!");
                        }
                    }
                } else {
                    //console.warn("Not enough Candle data for resistance levels.");
                }

                // If no signal was detected
                if (currentSignalCandle === "") {
                    currentSignalCandle = "Continuation";
                    directionSignalCandle = "Flat";
                    //console.log("No significant signal detected. Continuation.");
                }

                if (currentSignalCandle === lastSignalCandle) {
                    counterCandle++;
                } else {
                    counterCandle = 1;
                    lastSignalCandle = currentSignalCandle;
                }
                showResultCandle(currentSignalCandle, directionSignalCandle);
            }

            function showResultCandle(signalCandle, directionCandle) {
                const resultBoxCandle = document.getElementById("showResultCandle");
                resultBoxCandle.innerHTML = `<h3>${counterCandle}. ${signalCandle} - ${directionCandle}</h3>`;
                resultBoxCandle.style.color =
                    directionCandle === "Up" ? "blue" :
                    directionCandle === "Down" ? "red" :
                    directionCandle === "Flat" ? "green" :
                    "gray";
            }

            //////////Candle Trend
            function detectTrend(prices, shortPeriod, longPeriod) {
                let trend = "";
                prices = prices.map(Number);

                /*
                if (prices.length < longPeriod) {
                    console.warn("Candle Not enough data to calculate moving averages.");
                    return "No Trend";
                }
                */
                const shortMA = calculateMovingAverage(prices.slice(0, shortPeriod));
                const longMA = calculateMovingAverage(prices.slice(0, longPeriod));

                //console.log(`Candle Short Moving Average (${shortPeriod}): ${shortMA}`);
                //console.log(`Candle Long Moving Average (${longPeriod}): ${longMA}`);

                if (shortMA > longMA) {
                    //console.log("Candle Uptrend detected!");
                    trend = "Uptrend";
                } else if (shortMA < longMA) {
                    //console.log("Candle Downtrend detected!");
                    trend = "Downtrend";
                } else {
                    //console.log("Candle No significant trend detected (Consolidation).");
                    trend = "Consolidation";
                }
                updateCandleTrend(trend);
                return trend;
            }

            function calculateMovingAverage(data) {
                const sum = data.reduce((acc, value) => acc + value, 0);
                return sum / data.length;
            }

            function analyzeMarket() {
                const trend = detectTrend(spotClose, 5, 20); // Short: 5, Long: 20-period MA
                //console.log("Candle Current Trend:", trend);
            }

            function updateCandleTrend(trend) {
                const candleTrend = document.getElementById("candleTrend");
                candleTrend.textContent = `Candle Trend: ${trend}`;

                candleTrend.style.color =
                    trend === "Uptrend" ? "blue" :
                    trend === "Downtrend" ? "red" :
                    trend === "Consolidation" ? "green" :
                    "gray";
            }

            analyzeMarket()
        }

        ///Purchase codes
        if (b.proposal && orderPlaced == true) {
            //console.log(b)
            if (b.echo_req.proposal == 1) {
                proposal_id = b.proposal["id"];
                lgcode = b.proposal["longcode"];
                ws.send(JSON.stringify({
                    buy: proposal_id,
                    price: sessionStorage.PurchaseOrder
                }));
            };
        };
        if (b.buy && orderPlaced == true) {
            if (b.echo_req.buy == proposal_id) {
                cntrid = b.buy["contract_id"];
                istrade = true;
                //tottrade+=1;
                isbuy = true;
                //ratio(false)
                ws.send(JSON.stringify({
                    proposal_open_contract: 1,
                    contract_id: cntrid,
                    subscribe: 1
                }));
                ws.send(JSON.stringify({
                    forget: proposal_id
                }));
            };
        };
        
        if (b.proposal_open_contract) {
            var duration_tick = Number(document.getElementById("ticksint_rise").value);
            if (b.echo_req.proposal_open_contract == 1 || b.echo_req.subscribe == 1) {
                if (isbuy && b.proposal_open_contract.entry_spot != undefined) {
                    barrier = (b.proposal_open_contract.entry_spot).toFixed(2)
                    b_start = new Date(b.proposal_open_contract.entry_tick_time * 1000)
                    var EntryTrade = '<span style="color: black;"> ' + barrier + '</span>'
                    entryTable(tradeNumber, EntryTrade)
                    isbuy = false;
                    oc += 1
                    s_prop = b_start
                    if (oc == 0) {
                        slines.push({
                            startValue: s_prop,
                            endValue: b_start,
                            color: "#00f2ff61"
                        });
                    }
                } else if (b.proposal_open_contract.entry_spot != undefined && b.proposal_open_contract.current_spot_time <= b.proposal_open_contract.expiry_time) {
                    ix += 1
                    if (oc > 0) {
                        slines.push({
                            startValue: s_prop,
                            endValue: b_start,
                            color: "#00f2ff61"
                        });
                    }
                    try {
                        if (b.proposal_open_contract.current_spot > barrier) {
                            if (b.proposal_open_contract.contract_type == "CALL") {
                                chart.options.axisX.stripLines[oc].color = "#5fff9875";
                            } else {
                                chart.options.axisX.stripLines[oc].color = "#ff5f5f75";
                            }
                        } else {
                            if (b.proposal_open_contract.contract_type == "CALL") {
                                chart.options.axisX.stripLines[oc].color = "#ff5f5f75";
                            } else {
                                chart.options.axisX.stripLines[oc].color = "#5fff9875";
                            }
                        }
                        //duration_tick
                        if (b.proposal_open_contract.current_spot_time <= b.proposal_open_contract.expiry_time) {
                            e_prop = new Date(b.proposal_open_contract.current_spot_time * 1000)
                        }
                        chart.options.axisX.stripLines[oc].startValue = s_prop;
                        chart.options.axisX.stripLines[oc].endValue = e_prop;
                        chart.render();
                    } catch (err) {}
                }

                if (b.proposal_open_contract["is_sold"] == 1) {
                    exitSpot = b.proposal_open_contract.exit_tick_display_value;
                    var pyt = b.proposal_open_contract["payout"];
                    var prf = b.proposal_open_contract["profit"];
                    sline = []
                    stopTrade = false;
                    isbuy = false;
                    ix = 0;
                    s_prop = 0;
                    //if WIn
                    if (prf > 0) {
                        var resultTrade = '<span style="color: #4CAF50;"> ' + currencySymbol + " " + prf.toFixed(2) + '</span>'
                        var exitTrade = '<span style="color: black;"> ' + exitSpot + '</span>'
                        resultTable(tradeNumber, resultTrade, exitTrade);
                        /////manual
                        setprofit(balance_now)
                        tradeInProgress = false;
                        document.getElementById("resetManTradeBtn").disabled = false;
                    } else {
                        var resultTrade = '<span style="color: #f20202;">' + currencySymbol + " " + Math.abs(prf).toFixed(2) + '</span>'
                        var exitTrade = '<span style="color: black;"> ' + exitSpot + '</span>'
                        resultTable(tradeNumber, resultTrade, exitTrade);
                        setprofit(balance_now)
                        tradeInProgress = false;
                        document.getElementById("resetManTradeBtn").disabled = false;
                    }
                }
            };
        };
        /////////
        ////Purchase codes
        var status = b.msg_type;
        if (isloading) {
            //console.log("isloading")
        }
        if (b.error && b.error.code == "AuthorizationRequired") {
            //console.log(b.error.code);
            if (document.getElementById("token").value == "") {
                blinKIputToken("Log", "Enter token id...");
            } else {
                blinKIputToken("Log", b.error.message);
            }
        }
        if (status == "authorize") {
            if (b.error && b.error.code == "InvalidToken") {
                //blinKIputToken("invalidTkn");
                //console.log(b.error.code);
                blinKIputToken("invalidTkn", "Token invalid...");
            } else {
                var balance;
                //console.log("Authorised");
                if (document.getElementById("token").value !== "") {
                    document.getElementById("tokenbtn").value = "";
                    document.getElementById("tokenbtn").value = "Connected";
                    document.getElementById("tokenbtn").disabled = true
                    document.getElementById("token").disabled = true
                    balance = b.authorize.balance;
                    var email = b.authorize.email;
                    currency = b.authorize.currency
                    console.log("currency: ", currency)
                }
                var currency_symbols = {
                    'USD': '$', 'EUR': '€', 'CRC': '₡', 'GBP': '£','ILS': '₪', 'INR': '₹', 'JPY': '¥', 'KRW': '₩', 
                    'NGN': '₦','PHP': '₱', 'PLN': 'zł', 'PYG': '₲', 'THB': '฿', 'UAH': '₴', 'VND': '₫'
                };
                var currency_name = currency;
                if (currency_symbols[currency_name] !== undefined) {
                    currencySymbol = currency_symbols[currency_name];
                }
                //sessionStorage.balanceStarting = balance;
                starting_balance = balance;
                connected = true;
                if (document.getElementById("token").value !== "") {
                    crAccount = b.authorize.loginid;
                    //Mask token Number
                    var input2 = crAccount.substring(4, 20)
                    crAccount = crAccount.replace(input2, "*****");
                    //save to Session Storage
                    sessionStorage.cr_accountSaved = crAccount;
                    //save to Session Storage
                    sessionStorage.balanceNow = parseFloat(balance);
                    balance_Disp = sessionStorage.balanceNow;
                    if (BalHide.checked == true) {
                        document.getElementById("displayBal").innerHTML = currencySymbol + " " + "********"
                    } else {
                        document.getElementById("displayBal").innerHTML = currencySymbol + " " + balance_Disp;
                    }
                    document.getElementById("accountdata").innerHTML = sessionStorage.cr_accountSaved;
                }
                CheckBalance();
                // console.log("CheckBalance()");
            }
        } else if (status == "balance") {
            if (document.getElementById("token").value !== "") {
                if (b.balance) {
                    balance_now = b.balance.balance;
                    //console.log("balance_now: ",balance_now);
                    //console.log("stakeinp_rise: ",stakeinp_rise.value);
                }
            }
        }
        //At restart reset profit clear table
        function resetProfit() {
            if (profit != 0) {
                profit = 0;
                tradeNumber = 0;
                starting_balance = balance_now;
                document.getElementById("displayProfitTxt").textContent = "$ 0.00";
                document.getElementById("displayProfitTxt").style.color = "black";
                clearTable();
            }
        }
        if (runOnce) {
            document.getElementById("tradeType").disabled = false;
            document.getElementById('tokenbtn').disabled = false;
            stakePayoutProposal("valid");
            runOnce = false;
        }
        document.getElementById("callbtn").addEventListener("click", function() {
            if (starting_balance == 0 || starting_balance == undefined && connected == false) {
                blinKIputToken("Log", "Enter token id...");
                //////
            } else {
                if (tradeInProgress == false) {
                    allowAutoTrade = true;
                    CallTrade();

                }
            }
        });
        document.getElementById("fallbtn").addEventListener("click", function() {
            if (starting_balance == 0 || starting_balance == undefined && connected == false) {
                blinKIputToken("Log", "Enter token id...");
            } else {
                if (tradeInProgress == false) {
                    allowAutoTrade = true;
                    PutTrade();

                }
            }
        });
        var resetManTrade = document.getElementById("resetManTradeBtn")
        resetManTrade.addEventListener("click", function() {
            resetProfit();
        });
    }; ////////Original code end
    ///Purchase codes set profit
    function setprofit(balance_now) {
        let color;
        balance_Disp = balance_now;
        if (BalHide.checked == true) {
            document.getElementById("displayBal").innerHTML = currencySymbol + " " + "********"
        } else {
            document.getElementById("displayBal").innerHTML = currencySymbol + " " + balance_Disp;
        }
        profit = balance_now - starting_balance;
        if (profit > 0) {
            color = '#4CAF50';
        } else if (profit == 0) {
            color = 'black';
        } else {
            color = '#f20202';
        }
        document.getElementById("displayProfit").innerHTML =
            '<span id="displayProfitTxt" style="color: ' + color + ';">' + currencySymbol + " " + profit.toFixed(2) + '</span>';
    }

    function CheckBalance() {
        ws.send(JSON.stringify({
            "balance": 1,
            "subscribe": 1
        }));
    }
    var rateCount = 0;
    //Scroll result table to bottom on results
    function gotoBottom(id) {
        var element = document.getElementById(id);
        element.scrollTop = element.scrollHeight - element.clientHeight;
    }
    //////////////////////////////////
    function getStakePayout(orderValid, tradeType, offset_Value, vanilla_Barrier, ldp_Option, stakeAmount, durationTick, tick_Option, duraSymbol, callback) {
        let returnProposals = [];
        let proposalIds = [];
        let orderUp = false;
        let orderDown = false;

        function trade_Type_direction(){
            let tradeTypeValue = tradeTypeElement.options[tradeTypeElement.selectedIndex].value;
            let dir_trade_Type;
            for (let i = 0; i < trade_Type.length; i++) {
                if (tradeTypeValue == trade_Type[i].tradeTypeValueList) {
                    dir_trade_Type = trade_Type[i].tradeTypeList.split("/");
                    break;
                }
            }
            return dir_trade_Type;
        }

        if (orderValid == "valid") {
            orderPlaced = false;
            orderUp = true;
            orderDown = true;
        } else if (orderValid == "Call") {
            orderPlaced = true;
            orderUp = true;
        } else if (orderValid == "Put") {
            orderPlaced = true;
            orderDown = true;
        }
        
        function handleProposalMessage(msg) {
            const data = JSON.parse(msg.data);
            if (data.msg_type === "proposal") {
                const errorType = data.error?.message;
                const contractType = data.echo_req?.contract_type;
                const proposalId = data.proposal?.id;
                const stake = data.proposal?.ask_price;
                const payout = data.proposal?.payout;
                const maxPayout = data.proposal?.validation_params?.payout;
                const minStake = data.proposal?.validation_params?.stake;
                if (proposalId) {
                    proposalIds.push(proposalId);
                }
                /*
                console.log("data: ",data)
                console.log("errorType: ",errorType)
                console.log("ask price: ",data.proposal?.ask_price)
                console.log("payout: ",data.proposal?.payout)
                console.log("max payout: ",data.proposal?.validation_params?.payout)
                console.log("min stake: ",data.proposal?.validation_params?.stake)
                console.log("");
                */
                if (data.error) {
                    // Proposal not successful
                    returnProposals.push({
                        contractType: contractType,
                        valid: false,
                        stake: stake,
                        payout: payout,
                        errorType: errorType
                    });
                } else {
                    // Proposal successful
                    returnProposals.push({
                        contractType: contractType,
                        valid: true,
                        stake: stake,
                        payout: payout,
                        errorType: errorType
                    });
                }
                // Check if we have both PUT and CALL responses
                if (returnProposals.length === 2) {
                    ws.removeEventListener("message", handleProposalMessage); // Remove the temporary listener
                    callback(returnProposals);
                    // Send forget requests for the received proposals
                    if (orderValid == "Valid") {
                        proposalIds.forEach((id) => {
                            ws.send(JSON.stringify({
                                forget: id
                            }));
                        });
                    }
                    runOnce = false;
                }
            }
        }
        // Add the temporary listener for messages
        ws.addEventListener("message", handleProposalMessage);
        const contractTypeArr = [{
                Rise: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "CALL",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                Fall: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "PUT",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                Higher: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "CALL",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: offset_Value
                }
            },
            {
                Lower: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "PUT",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: offset_Value
                }
            },
            {
                Touch: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "ONETOUCH",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: offset_Value
                }
            },
            {
                NoTouch: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "NOTOUCH",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: offset_Value
                }
            },
            {
                OnlyUps: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "RUNHIGH",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                OnlyDowns: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "RUNLOW",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                High: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "TICKHIGH",
                    symbol: rnd,
                    duration: 5,
                    selected_tick: parseInt(tick_Option),
                    currency: currency,
                    duration_unit: "t"
                }
            },
            {
                LowTicks: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "TICKLOW",
                    symbol: rnd,
                    duration: 5,
                    selected_tick: parseInt(tick_Option),
                    currency: currency,
                    duration_unit: "t"
                }
            },
            {
                Over: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "DIGITOVER",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: ldp_Option
                }
            },
            {
                Under: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "DIGITUNDER",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: ldp_Option
                }
            },
            {
                Even: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "DIGITEVEN",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                Odd: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "DIGITODD",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                Matches: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "DIGITMATCH",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: ldp_Option
                }
            },
            {
                Differs: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "DIGITDIFF",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol,
                    barrier: ldp_Option
                }
            },
            {
                AsianUp: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "ASIANU",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                AsianDown: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "ASIAND",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                VanillaCall: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "VANILLALONGCALL",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: "m",
                    barrier: vanilla_Barrier
                }
            },
            {
                Put: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "VANILLALONGPUT",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: "m",
                    barrier: vanilla_Barrier
                }
            },
            {
                ResetUp: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "RESETCALL",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            },
            {
                ResetDown: {
                    proposal: 1,
                    amount: parseFloat(stakeAmount),
                    basis: "stake",
                    contract_type: "RESETPUT",
                    symbol: rnd,
                    duration: parseInt(durationTick),
                    currency: currency,
                    duration_unit: duraSymbol
                }
            }
        ];
        // Function to get the contract parameters based on trade type
        function getContractParams(tradeTypeSeparated) {
            let tradeTypeNOSapce = tradeTypeSeparated.replace(/\s+/g, "");
            const contract = contractTypeArr.find(obj => obj[tradeTypeNOSapce]);
            if (contract) {
                return contract[tradeTypeNOSapce];
            } else {
                //console.error(`Trade type "${tradeTypeNOSapce}" not found!`);
                return null;
            }
        }
        let tradeTypeUP = tradeType.split("/")[0];
        const contractParamsUp = getContractParams(tradeTypeUP);
        if (contractParamsUp && orderUp) {
            //console.log("Contract Parameters for Up:", contractParamsUp);
            ws.send(JSON.stringify(contractParamsUp));
            if (orderPlaced) {
                mirrorTrade(contractParamsUp, trade_Type_direction()[0]);
            }
        }
        let tradeTypeDown = tradeType.split("/")[1];
        const contractParamsDown = getContractParams(tradeTypeDown);
        if (contractParamsDown && orderDown) {
            //console.log("Contract Parameters for Down:", contractParamsDown);
            ws.send(JSON.stringify(contractParamsDown));
            if (orderPlaced) {
                mirrorTrade(contractParamsDown, trade_Type_direction()[1]);
            }
        }
        /*
        if (tradeType == "Higher/Lower") {
        ws.send(JSON.stringify({ proposal: 1, amount: parseFloat(stakeAmount), basis: "stake", contract_type: "PUT", currency: currency, duration: parseInt(durationTick), duration_unit: duraSymbol, barrier: offset_Value, symbol: rnd }));
        ws.send(JSON.stringify({ proposal: 1, amount: parseFloat(stakeAmount), basis: "stake", contract_type: "CALL", currency: currency, duration: parseInt(durationTick), duration_unit: duraSymbol, barrier: offset_Value, symbol: rnd }));
        } else {
        ws.send(JSON.stringify({ proposal: 1, amount: parseFloat(stakeAmount), basis: "stake", contract_type: "PUT", currency: currency, duration: parseInt(durationTick), duration_unit: duraSymbol, symbol: rnd }));
        ws.send(JSON.stringify({ proposal: 1, amount: parseFloat(stakeAmount), basis: "stake", contract_type: "CALL", currency: currency, duration:parseInt(durationTick), duration_unit: duraSymbol, symbol: rnd }));
        }
        */
        rateCount++;
        // console.log("rateCount: ",rateCount)
    }

    function stakePayoutProposal(orderValid) {
        let putValid;
        let callValid;
        let putStake, putPayout, callStake, callPayout, callErrorType, putErrorType;
        let barrier_Input, ldp_Option, tick_Option, vanilla_Barrier;
        let tradeTypeElement = document.getElementById("tradeType");
        let tradeType = tradeTypeElement.options[tradeTypeElement.selectedIndex].text;
        let stakeAmount = document.getElementById('stakeinp_rise').value;
        let durationTick = document.getElementById('ticksint_rise');
        let duralistMan = document.getElementById("duraListMan");
        let dura_Symbol = {
            'ticks': 't',
            'seconds': 's',
            'minutes': 'm',
            'hours': 'h',
            'days': 'd'
        };
        let durSelect = "";
        if (durationTick) {
            durationTick = durationTick.value;
            durSelect = duralistMan.options[duralistMan.selectedIndex].text;
        } else {
            durationTick = "5";
            durSelect = "ticks";
        }
        let duraSymbol = dura_Symbol[durSelect];
        if (tradeType == "Higher/Lower") {
            let toggleSwitch = document.getElementById("toggleSwitch")
            let inputField = document.getElementById("barrier_Input");
            let inputFieldMinus = document.getElementById("barrier_Input_Minus");
            if (toggleSwitch.checked) {
                barrier_Input = inputField.value;
            } else {
                barrier_Input = inputFieldMinus.value;
            }
        } else if (tradeType == "Touch/No Touch") {
            barrier_Input = document.getElementById('barrier_Input').value;
        } else if (tradeType == "Over/Under" || tradeType == "Matches/Differs") {
            let ldpOptionElem = document.getElementById("ldpOption");
            ldp_Option = ldpOptionElem.options[ldpOptionElem.selectedIndex].text;
        } else if (tradeType == "High/Low Ticks") {
            let tickOptionElem = document.getElementById("tickOption");
            tick_Option = tickOptionElem.options[tickOptionElem.selectedIndex].text;
        } else if (tradeType == "Vanilla Call/Put") {
            let vanillaBarrierOptionElem = document.getElementById("vanillaBarrierOption");
            vanilla_Barrier = vanillaBarrierOptionElem.options[vanillaBarrierOptionElem.selectedIndex].text;
            //console.log("vanilla_Barrier1: ",vanilla_Barrier)
        }
        getStakePayout(orderValid, tradeType, barrier_Input, vanilla_Barrier, ldp_Option, stakeAmount, durationTick, tick_Option, duraSymbol, (proposals) => {
            //!!!console.log("proposals: ",proposals)
            let putIndex = -1;
            let callIndex = -1;
            let contractTypeUp = ["CALL", "ONETOUCH", "RUNHIGH", "TICKHIGH", "DIGITOVER", "DIGITEVEN", "DIGITMATCH", "ASIANU", "VANILLALONGCALL", "RESETCALL"];
            let contractTypeDown = ["PUT", "NOTOUCH", "RUNLOW", "TICKLOW", "DIGITUNDER", "DIGITODD", "DIGITDIFF", "ASIAND", "VANILLALONGPUT", "RESETPUT"];
            for (let i = 0; i < proposals.length; i++) {
                if (contractTypeUp.includes(proposals[i].contractType)) {
                    callIndex = i;
                    callValid = proposals[callIndex].valid;
                } else if (contractTypeDown.includes(proposals[i].contractType)) {
                    putIndex = i;
                    putValid = proposals[putIndex].valid;
                }
            }
            let callBtn = document.getElementById("callbtn");
            let fallBtn = document.getElementById("fallbtn");
            //!!!console.log("callValid: ",callValid)
            //!!!console.log("putValid: ",putValid)
            const callStakeLblElem = document.getElementById('callStakeLbl');
            const callStakeValueElem = document.getElementById('callStakeValue');
            const callPayoutLblElem = document.getElementById('callPayoutLbl');
            const callPayoutValueElem = document.getElementById('callPayoutValue');
            const callNetprofitElem = document.getElementById('callNetprofit');
            callStakeLblElem.innerText = "Stake:";
            callPayoutLblElem.innerHTML = "Payout:";
            if (callValid == true) {
                callStake = proposals[callIndex].stake;
                callPayout = proposals[callIndex].payout;
                const callNetProfit = (callPayout - callStake).toFixed(2);
                const callPercentage = ((callNetProfit / callStake) * 100).toFixed(1);
                callStakeValueElem.innerHTML = `${callStake.toFixed(2)} ${currency}`;
                callPayoutValueElem.innerHTML = `${callPayout.toFixed(2)} ${currency}`;
                callNetprofitElem.innerText = `Net profit: ${callNetProfit} ${currency} | Return ${callPercentage}%`;
                if (callBtn.disabled = true) {
                    callBtn.classList = "";
                    callBtn.classList = "risebtn";
                    callBtn.disabled = false;
                }
            } else if (callValid == false) {
                if(proposals[callIndex].errorType) {
                    callErrorType = proposals[callIndex].errorType;
                }
                callStakeValueElem.innerHTML = "-";
                callPayoutValueElem.innerHTML = "-";
                callNetprofitElem.innerText = callErrorType;
                if (callBtn.classList != "notActiveBtn") {
                    callBtn.classList = "";
                    callBtn.classList = "notActiveBtn";
                    callBtn.disabled = true;
                }
            }
            const putStakeLblElem = document.getElementById('putStakeLbl');
            const putStakeValueElem = document.getElementById('putStakeValue');
            const putPayoutLblElem = document.getElementById('putPayoutLbl');
            const putPayoutValueElem = document.getElementById('putPayoutValue');
            const putNetprofitElem = document.getElementById('putNetprofit');
            putStakeLblElem.innerText = "Stake:";
            putPayoutLblElem.innerHTML = "Payout:";
            if (putValid == true) {
                putStake = proposals[putIndex].stake;
                putPayout = proposals[putIndex].payout;
                const putNetProfit = (putPayout - putStake).toFixed(2);
                const putPercentage = ((putNetProfit / putStake) * 100).toFixed(1);
                putStakeValueElem.innerHTML = `${putStake.toFixed(2)} ${currency}`;
                putPayoutValueElem.innerHTML = `${putPayout.toFixed(2)} ${currency}`;
                putNetprofitElem.innerText = `Net profit: ${putNetProfit} ${currency} | Return ${putPercentage}%`;
                if (fallBtn.disabled = true) {
                    fallBtn.classList = "";
                    fallBtn.classList = "fallbtn";
                    fallBtn.disabled = false;
                }
            } else if (putValid == false) {
                putErrorType = proposals[putIndex].errorType;
                putStakeValueElem.innerHTML = "-";
                putPayoutValueElem.innerHTML = "-";
                putNetprofitElem.innerText = putErrorType;
                if (fallBtn.classList != "notActiveBtn") {
                    fallBtn.classList = "";
                    fallBtn.classList = "notActiveBtn";
                    fallBtn.disabled = true;
                }
            }
            if (proposals[callIndex].errorType) {
                if ((proposals[callIndex].errorType).includes("Barriers available are")) {
                    const barrier_available = (proposals[callIndex].errorType).match(/[+-]?\d+\.\d+/g);
                    //console.log(barrier_available);
                    updateSelectOptions(barrier_available);
                }
            }
        });
    }

    function updateSelectOptions(barrier_available) {
        const vanillaOptionElem = document.getElementById("vanillaBarrierOption");
        vanillaOptionElem.innerHTML = "";
        barrier_available.forEach((text) => {
            const option = document.createElement("option");
            option.textContent = text;
            vanillaOptionElem.appendChild(option);
        });
        stakePayoutProposal("valid");
    }
    /////////Set amount greater than 0
    stakeinp_rise = document.getElementById('stakeinp_rise');
    stakeinp_rise.addEventListener('input', function() {
        let callBtn = document.getElementById("callbtn");
        let fallBtn = document.getElementById("fallbtn");
        stakePayoutProposal("valid");
        if (stakeinp_rise.value == "" || stakeinp_rise.value > balance_Disp) {
            if (callBtn.classList != "notActiveBtn") {
                callBtn.classList = "";
                callBtn.classList = "notActiveBtn";
                callBtn.disabled = true;
                fallBtn.classList = "";
                fallBtn.classList = "notActiveBtn";
                fallBtn.disabled = true;
            }
        } else {
            if (callBtn.disabled = true) {
                callBtn.classList = "";
                callBtn.classList = "risebtn";
                callBtn.disabled = false;
                fallBtn.classList = "";
                fallBtn.classList = "fallbtn";
                fallBtn.disabled = false;
            }
        }
    });
    /////////Set duration box to limit to 10
    var inputDuration = document.getElementById('ticksint_rise');
    inputDuration.addEventListener('input', function() {
        let dura_unit_Min = {
            't': MinTickDura,
            's': '15',
            'm': '1',
            'h': '1',
            'd': '1'
        };
        let dura_unit_Max = {
            't': '10',
            's': '86400',
            'm': '1440',
            'h': '24',
            'd': '365'
        };
        let minText = document.getElementById("minDuration");
        let callBtn = document.getElementById("callbtn");
        let fallBtn = document.getElementById("fallbtn");
        stakePayoutProposal("valid");
        if (parseInt(inputDuration.value) < parseInt(dura_unit_Min[duraSymbol]) || inputDuration.value == "") {
            minText.style.color = "red";
            minText.style.fontStyle = "italic";
            minText.textContent = 'Minimum: ' + dura_unit_Min[duraSymbol];
            if (callBtn.classList != "notActiveBtn") {
                callBtn.classList = "";
                callBtn.classList = "notActiveBtn";
                callBtn.disabled = true;
                fallBtn.classList = "";
                fallBtn.classList = "notActiveBtn";
                fallBtn.disabled = true;
            }
        } else if (parseInt(inputDuration.value) > parseInt(dura_unit_Max[duraSymbol])) {
            minText.style.color = "red";
            minText.style.fontStyle = "italic";
            minText.textContent = 'Maximum: ' + dura_unit_Max[duraSymbol];
            if (callBtn.classList != "disbled_RFBtn") {
                callBtn.classList = "";
                callBtn.classList = "disbled_RFBtn";
                callBtn.disabled = true;
                fallBtn.classList = "";
                fallBtn.classList = "disbled_RFBtn";
                fallBtn.disabled = true;
            }
        } else {
            minText.style.color = "gray";
            minText.style.fontStyle = "normal";
            minText.textContent = 'Minimum: ' + dura_unit_Min[duraSymbol];
            if (callBtn.disabled = true) {
                callBtn.classList = "";
                callBtn.classList = "risebtn";
                callBtn.disabled = false;
                fallBtn.classList = "";
                fallBtn.classList = "fallbtn";
                fallBtn.disabled = false;
            }
        }
    });
    ////////
    let defaultArea =
        `<div>
        <label style="font-weight: normal; margin-right: 10px; font-size: 9px;">Barrier offset(+)</label>
        <input id="barrier_Input" type="text" class="inputClss"
        style="margin-top: 8px; border-style: groove; font-weight: bold; width: 40px;"
        placeholder="input" value="+0.25">
        </div>
        <div>
        <label style="font-weight: normal; margin-right: 10px; font-size: 9px;">Barrier offset(-)</label>
        <input id="barrier_Input_Minus" type="text" class="inputClss"
        style="margin-top: 7px; border-style: groove; font-weight: bold; width: 40px;"
        placeholder="input" value="-0.25">
        </div>`
    let barrierOffsetBox2 =
        `<div>
        <label style="font-weight: normal; margin-right: 10px; font-size: 9px;">Barrier offset(+)</label>
        <input id="barrier_Input" type="text" class="inputClss"
        style="margin-top: 8px; border-style: groove; font-weight: bold; width: 40px;"
        placeholder="input" value="+0.25">
        </div>
        <div>
        <label style="font-weight: normal; margin-right: 10px; font-size: 9px;">Barrier offset(-)</label>
        <input id="barrier_Input_Minus" type="text" class="inputClss"
        style="margin-top: 8px; border-style: groove; font-weight: bold; width: 40px;"
        placeholder="input" value="-0.25">
        </div>`
    let barrierOffsetBoxSwitch2 =
        `<label class="switch">
        <input type="checkbox" id="toggleSwitch" checked>
        <span class="slider"></span>
        </label>`
    let barrierOffsetBox =
        `<div style= "margin-top: 12px; ">
        <label id = '' class="" style="font-weight:normal; margin-right: 10px; font-size: 10px;">Barrier offset</label>
        <input id="barrier_Input" type="text" class="inputClss" style="margin-top: 5px; border-style: groove; font-weight:bold; width: 60px;" placeholder="input" value="+0.25">
        </div>
        <label id="inBarrier" class="" style= "font-Style: italic; font-size: 10px;">Indicative barrier :</label>`
    let ldPredictonBox =
        `<div>
        <label id = '' class="" style="font-weight:normal; margin-right: 10px; font-size: 10px;">Last Digit Prediction</label>
        <select id = "ldpOption" style="margin-top: 24px; margin-bottom: 14px; border-style: groove; font-weight:bold; width: 50px;">
        <option value="0">0</option><option value="1">1</option>
        <option value="2">2</option><option value="3">3</option>
        <option value="4">4</option><option value="5">5</option>
        <option value="6">6</option><option value="7">7</option>
        <option value="8">8</option><option value="9">9</option>
        </select>
        <label class="" style= "font-Style: italic; font-size: 15px;"></label>
        </div>`
    let tickPredictonBox =
        `<div>
        <label id = '' class="" style="margin-top: 30px; font-weight:normal; margin-right: 10px; font-size: 10px;">Tick Prediction</label>
        <select id = "tickOption" style="margin-top: 16px; margin-bottom: 22px;border-style: groove; font-weight:bold; width: 50px;">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        </select>
        <label class="" style= "font-Style: italic; font-size: 15px;"></label>
        </div>`
    let durationNormal = `
        <label align="left" style="font-weight:normal; font-size: 12px;">Duration: </label>
        <input class="inputClss" id="ticksint_rise"  align="left"  type="text" style="width: 25px;" value="5" onkeypress="return event.charCode >= 48 && event.charCode <= 57"></input>
        <select id = "duraListMan" style="font-size: 10px; height :20px; border-radius: 4px;">
        <option> ticks </option>
        <option> seconds </option>
        <option> minutes </option>
        <option> hours </option>
        <option> days </option>
        </select>
        <label id="minDuration" class="" style="display: block; font-size: 11px; color: gray; margin-top: 5px;">Minimum: 1</label>`
    let duraHighLowTick = `
        <th colspan="2" id="TitleDuraAccInfo" style="margin-top: 22px;" class="tables_stake_duration_lbl" align="center">
        <div class="info-box" >
        <i>&#9432;</i>
        <span>This contract type only offers 5 ticks</span>
        </div>
        </th>`
    let vanillaBarrierBox =
        `<div>
        <label id = '' class="" style=font-weight:normal; margin-right: 10px; font-size: 10px;">Barrier Prediction</label>
        <select id = "vanillaBarrierOption" style="margin-top: 6px; margin-bottom: 14px;border-style: groove; font-weight:bold; width: 60px;">
        <option>+8.00</option>
        <option>+4.20</option>
        <option>+0.00</option>
        <option>-4.20</option>
        <option>-8.00</option>
        </select>
        <label class="" style= "font-Style: italic; font-size: 15px;"></label>
        </div>`
    let trade_Type = [{
            tradeTypeValueList: "1",
            tradeTypeList: "Rise/Fall",
            contractTypeList: "CALL_PUT",
            durationList: "1_10",
            extraSetDisp: `${defaultArea}`,
            Iset: "DA"
        },
        {
            tradeTypeValueList: "2",
            tradeTypeList: "Higher/Lower",
            contractTypeList: "CALL_PUT",
            durationList: "5_10",
            extraSetDisp: `${barrierOffsetBox2}`,
            Iset: "BOS"
        },
        {
            tradeTypeValueList: "3",
            tradeTypeList: "Touch/No Touch",
            contractTypeList: "ONETOUCH_NOTOUCH",
            durationList: "5_10",
            extraSetDisp: `${barrierOffsetBox}`,
            Iset: "BOS"
        },
        {
            tradeTypeValueList: "4",
            tradeTypeList: "Ups/Downs",
            contractTypeList: "EXPIRYRANGE_EXPIRYMISSEDRANGE",
            durationList: "2_5",
            extraSetDisp: `${defaultArea}`,
            Iset: "DA"
        },
        {
            tradeTypeValueList: "5",
            tradeTypeList: "High/Low",
            contractTypeList: "TICKHIGH_TICKLOW",
            durationList: "5_5",
            extraSetDisp: `${tickPredictonBox}`,
            Iset: "TPB"
        },
        {
            tradeTypeValueList: "6",
            tradeTypeList: "Over/Under",
            contractTypeList: "DIGITOVER_DIGITUNDER",
            durationList: "1_9",
            extraSetDisp: `${ldPredictonBox}`,
            Iset: "LPB"
        },
        {
            tradeTypeValueList: "7",
            tradeTypeList: "Even/Odd",
            contractTypeList: "DIGITEVEN_DIGITODD",
            durationList: "1_10",
            extraSetDisp: `${defaultArea}`,
            Iset: "DA"
        },
        {
            tradeTypeValueList: "8",
            tradeTypeList: "Matches/Differs",
            contractTypeList: "DIGITMATCH_DIGITDIFF",
            durationList: "1_10",
            extraSetDisp: `${ldPredictonBox}`,
            Iset: "LPB"
        },
        {
            tradeTypeValueList: "9",
            tradeTypeList: "Up/Down",
            contractTypeList: "ASIANCALL_ASIANPUT",
            durationList: "5_10",
            extraSetDisp: `${defaultArea}`,
            Iset: "DA"
        },
        {
            tradeTypeValueList: "10",
            tradeTypeList: "Call/Put",
            contractTypeList: "VANILLACALL_VANILLAPUT",
            durationList: "",
            extraSetDisp: `${vanillaBarrierBox}`,
            Iset: "VBB"
        },
        {
            tradeTypeValueList: "11",
            tradeTypeList: "Up/Down",
            contractTypeList: "RESETCALL_RESETPUT",
            durationList: "5_10",
            extraSetDisp: `${defaultArea}`,
            Iset: "DA"
        },
    ];
    ////////
    var tradeTypeElement = document.getElementById("tradeType");
    tradeTypeElement.addEventListener('change', function() {
        // Prevent auto-trade unless explicitly triggered
        allowAutoTrade = false;
        let tradeTypeValue = tradeTypeElement.options[tradeTypeElement.selectedIndex].value;
        const extraSetBoxElement = document.getElementById("extraSetBox");
        const extraSetBoxSwitchElement = document.getElementById("extraSetBoxSwitch");
        let minDuraDisp = document.getElementById("minDuration");
        let callbtnElem = document.getElementById("callbtn");
        let putbtnElem = document.getElementById("fallbtn");
        for (let i = 0; i < trade_Type.length; i++) {
            if (tradeTypeValue == trade_Type[i].tradeTypeValueList) {
                if (trade_Type[i].Iset == "DA") {
                    extraSetBoxElement.style.visibility = "hidden";
                } else {
                    extraSetBoxElement.style.visibility = "visible";
                }
                if (trade_Type[i].tradeTypeList == "Higher/Lower") {
                    extraSetBoxSwitchElement.innerHTML = "";
                    extraSetBoxSwitchElement.innerHTML = barrierOffsetBoxSwitch2;
                } else {
                    extraSetBoxSwitchElement.innerHTML = "";
                }
                extraSetBoxElement.innerHTML = "";
                extraSetBoxElement.innerHTML = trade_Type[i].extraSetDisp;
                let InputDuraAcc = document.getElementById("InputDuraAccInfo");
                tradeType = tradeTypeElement.options[tradeTypeElement.selectedIndex].text;
                if (tradeType == "High/Low Ticks") {
                    InputDuraAcc.innerHTML = "";
                    InputDuraAcc.innerHTML = duraHighLowTick;
                } else {
                    InputDuraAcc.innerHTML = "";
                    InputDuraAcc.innerHTML = durationNormal;
                    minDuraDisp = document.getElementById("minDuration");
                    MinTickDura = trade_Type[i].durationList.split("_")[0];
                    minDuraDisp.textContent = `Minimum: ${MinTickDura}`
                }
                if (trade_Type[i].tradeTypeList == "Higher/Lower") {
                    let toggleSwitch = document.getElementById("toggleSwitch");
                    if (toggleSwitch.checked) {
                        callbtnElem.textContent = `+ ${trade_Type[i].tradeTypeList.split("/")[0]}`;
                        putbtnElem.textContent = `+ ${trade_Type[i].tradeTypeList.split("/")[1]}`;
                    } else {
                        callbtnElem.textContent = `- ${trade_Type[i].tradeTypeList.split("/")[0]}`;
                        putbtnElem.textContent = `- ${trade_Type[i].tradeTypeList.split("/")[1]}`;
                    }
                } else {
                    callbtnElem.textContent = trade_Type[i].tradeTypeList.split("/")[0];
                    putbtnElem.textContent = trade_Type[i].tradeTypeList.split("/")[1];
                }
                break;
            }
        }
        stakePayoutProposal("valid");
    });
    var duralistMan = document.getElementById("duraListMan");
    duralistMan.addEventListener('change', function() {
        durSelect = duralistMan.options[duralistMan.selectedIndex].text
        let dura_unit = {
            'ticks': MinTickDura,
            'seconds': '15',
            'minutes': '1',
            'hours': '1',
            'days': '1'
        };
        let dura_unit_Min = {
            't': MinTickDura,
            's': '15',
            'm': '1',
            'h': '1',
            'd': '1'
        };
        let dura_unit_Max = {
            't': '10',
            's': '86400',
            'm': '1440',
            'h': '24',
            'd': '365'
        };
        let dura_Symbol = {
            'ticks': 't',
            'seconds': 's',
            'minutes': 'm',
            'hours': 'h',
            'days': 'd'
        };
        let callBtn = document.getElementById("callbtn");
        let fallBtn = document.getElementById("fallbtn");
        duraSymbol = dura_Symbol[durSelect];
        stakePayoutProposal("valid");
        let minText = document.getElementById("minDuration");
        if (parseInt(document.getElementById("ticksint_rise").value) < parseInt(dura_unit_Min[duraSymbol])) {
            minText.textContent = 'Minimum: ' + dura_unit_Min[duraSymbol];
            minText.style.color = "red";
            minText.style.fontStyle = "italic";
            callBtn.classList = "";
            callBtn.classList = "disbled_RFBtn";
            callBtn.disabled = true;
            fallBtn.classList = "";
            fallBtn.classList = "disbled_RFBtn";
            fallBtn.disabled = true;
        } else if (parseInt(document.getElementById("ticksint_rise").value) > parseInt(dura_unit_Max[duraSymbol])) {
            minText.textContent = 'Maximiun: ' + dura_unit_Max[duraSymbol];
            minText.style.color = "red";
            minText.style.fontStyle = "italic";
            callBtn.classList = "";
            callBtn.classList = "disbled_RFBtn";
            callBtn.disabled = true;
            fallBtn.classList = "";
            fallBtn.classList = "disbled_RFBtn";
            fallBtn.disabled = true;
        } else {
            minText.textContent = 'Minimum: ' + dura_unit_Min[duraSymbol];
            minText.style.color = "gray";
            minText.style.fontStyle = "normal";
            callBtn.classList = "";
            callBtn.classList = "risebtn";
            callBtn.disabled = false;
            fallBtn.classList = "";
            fallBtn.classList = "fallbtn";
            fallBtn.disabled = false;
        }
    });
    document.body.addEventListener('input', function(e) {
        if (e.target && e.target.id === 'tickOption') {
            tickOption = e.target.options[e.target.selectedIndex].text
            //console.log("tickOption: ",tickOption)
            stakePayoutProposal("valid");
        }
        if (e.target && e.target.id === 'ldpOption') {
            ldpOption = e.target.options[e.target.selectedIndex].text
            //console.log("ldpOption: ",ldpOption)
            stakePayoutProposal("valid");
        }
        if (e.target && e.target.id === 'vanillaBarrierOption') {
            vanillaBarrierOption = e.target.options[e.target.selectedIndex].text
            //console.log("vanillaBarrierOption: ",vanillaBarrierOption)
            stakePayoutProposal("valid");
        }
    });
    document.body.addEventListener('change', function(e) {
        if (e.target && e.target.id === 'toggleSwitch') {
            let tradeTypeText = tradeTypeElement.options[tradeTypeElement.selectedIndex].text;
            let toggleSwitch = document.getElementById("toggleSwitch");
            let callbtnElem = document.getElementById("callbtn");
            let putbtnElem = document.getElementById("fallbtn");
            if (toggleSwitch.checked) {
                callbtnElem.textContent = `+ ${tradeTypeText.split("/")[0]}`;
                putbtnElem.textContent = `+ ${tradeTypeText.split("/")[1]}`;
            } else {
                callbtnElem.textContent = `- ${tradeTypeText.split("/")[0]}`;
                putbtnElem.textContent = `- ${tradeTypeText.split("/")[1]}`;
            }
            stakePayoutProposal("valid");
        }
    });
    var barrier_Input = '';
    document.body.addEventListener('input', function(e) {
        if (e.target && e.target.id === 'barrier_Input' || e.target.id === 'barrier_Input_Minus') {
            const match = e.target.value.match(/[-+]?\d*\.?\d*/);
            if (match || e.target.value === '') {
                barrier_Input = match ? match[0] : '';
            }
            e.target.value = barrier_Input;
            stakePayoutProposal("valid");
            //callBtn
            let callBtn = document.getElementById("callbtn");
            if (barrier_Input == "" || barrier_Input == "+" || barrier_Input == "-" || barrier_Input.endsWith('.')) {
                if (callBtn.classList != "notActiveBtn") {
                    callBtn.classList = "";
                    callBtn.classList = "notActiveBtn";
                    callBtn.disabled = true;
                }
            } else {
                if (callBtn.disabled = true) {
                    callBtn.classList = "";
                    callBtn.classList = "risebtn";
                    callBtn.disabled = false;
                }
            }
            //fallBtn
            let fallBtn = document.getElementById("fallbtn");
            if (barrier_Input == "" || barrier_Input == "+" || barrier_Input == "-" || barrier_Input.endsWith('.')) {
                if (fallBtn.classList != "notActiveBtn") {
                    fallBtn.classList = "";
                    fallBtn.classList = "notActiveBtn";
                    fallBtn.disabled = true;
                }
            } else {
                if (fallBtn.disabled = true) {
                    fallBtn.classList = "";
                    fallBtn.classList = "fallbtn";
                    fallBtn.disabled = false;
                }
            }
        }
    });

    function PutTrade() {
        orderPlaced = true;
        tradeNumber++;
        let PurchaseOrderx = "";
        let total_tick = "";
        PurchaseOrderx = Number(document.getElementById("stakeinp_rise").value);
        total_tick = document.getElementById("ticksint_rise").value;
        document.getElementById("resetManTradeBtn").disabled = true;
        /*
        let direction ="";
        let barrier_Input = "";
        let tradeTypeElement = document.getElementById("tradeType");
        let tradeType = tradeTypeElement.options[tradeTypeElement.selectedIndex].text
        if (tradeType == "Higher/Lower") {
            direction = ' Lower ';
            barrier_Input = document.getElementById("barrier_Input").value;
        } else if (tradeType == "Rise/Fall") {
            direction = ' Fall ';
            barrier_Input = "0";
        }
        */
        let tradeTypeValue = tradeTypeElement.options[tradeTypeElement.selectedIndex].value;
        let direction_Down;
        for (let i = 0; i < trade_Type.length; i++) {
            if (tradeTypeValue == trade_Type[i].tradeTypeValueList) {
                direction_Down = trade_Type[i].tradeTypeList.split("/")[1];
                break;
            }
        }

        //console.trace('[TRACE] Triggering sendBuy for', direction_Down);

        let PurchaseOrder = PurchaseOrderx.toFixed(2);
        sessionStorage.PurchaseOrder = PurchaseOrder
        timestamp = getTimeFixed(new Date());
        var timeTrade = '<span style="color: #003edb;"> ' + timestamp + '</span>'
        //var detailTrade = '<span style="color: #003edb;"> ' + ' Fall ' + currencySymbol + " " + PurchaseOrder + '</span>'
        var detailTrade = '<span style="color: #003edb;"> ' + ` ${direction_Down} ` + currencySymbol + " " + PurchaseOrder + '</span>'
        directionTable(tradeNumber, timeTrade, detailTrade);
        gotoBottom("tbTrade");
        stakePayoutProposal("Put");
        /*
        if (tradeType == "Higher/Lower") {
            ws.send(JSON.stringify({proposal:1,amount:sessionStorage.PurchaseOrder,basis:"stake",contract_type:"PUT",currency:currency,duration:total_tick,duration_unit:duraSymbol, barrier: barrier_Input,symbol:rnd }));
        } else if (tradeType == "Rise/Fall") {
            ws.send(JSON.stringify({proposal:1,amount:sessionStorage.PurchaseOrder,basis:"stake",contract_type:"PUT",currency:currency,duration:total_tick,duration_unit:duraSymbol,symbol:rnd}));
        }
        */
        tradeInProgress = true;
    }

    function CallTrade() {
        orderPlaced = true;
        tradeNumber++;
        let PurchaseOrderx = "";
        let total_tick = "";
        PurchaseOrderx = Number(document.getElementById("stakeinp_rise").value);
        total_tick = document.getElementById("ticksint_rise").value;
        document.getElementById("resetManTradeBtn").disabled = true;
        /*
        let direction ="";
        let barrier_Input = "";
        let tradeTypeElement = document.getElementById("tradeType");
        let tradeType = tradeTypeElement.options[tradeTypeElement.selectedIndex].text
        if(tradeType == "Higher/Lower") {
            //direction = ' Higher ';
            barrier_Input = document.getElementById("barrier_Input").value;
        } else if(tradeType == "Rise/Fall") {
            //direction = ' Rise ';
            barrier_Input = "0";
        }
        */
        let tradeTypeValue = tradeTypeElement.options[tradeTypeElement.selectedIndex].value;
        let direction_Up;
        for (let i = 0; i < trade_Type.length; i++) {
            if (tradeTypeValue == trade_Type[i].tradeTypeValueList) {
                direction_Up = trade_Type[i].tradeTypeList.split("/")[0];
                break;
            }
        }

        //console.trace('[TRACE] Triggering sendBuy for', direction_Up);

        let PurchaseOrder = PurchaseOrderx.toFixed(2);
        sessionStorage.PurchaseOrder = PurchaseOrder
        timestamp = getTimeFixed(new Date());
        let timeTrade = '<span style="color: #003edb;"> ' + timestamp + '</span>'
        //let detailTrade = '<span style="color: #003edb;"> ' + ' Rise ' + currencySymbol + " " + PurchaseOrder + '</span>'
        let detailTrade = '<span style="color: #003edb;"> ' + ` ${direction_Up} ` + currencySymbol + " " + PurchaseOrder + '</span>'
        directionTable(tradeNumber, timeTrade, detailTrade);
        gotoBottom("tbTrade");
        stakePayoutProposal("Call");
        /*
        if (tradeType == "Higher/Lower") {
            ws.send(JSON.stringify({proposal:1,amount:sessionStorage.PurchaseOrder,basis:"stake",contract_type:"CALL",currency:currency,duration:total_tick,duration_unit:duraSymbol, barrier: barrier_Input,symbol:rnd}));
        } else if (tradeType == "Rise/Fall") {
            ws.send(JSON.stringify({proposal:1,amount:sessionStorage.PurchaseOrder,basis:"stake",contract_type:"CALL",currency:currency,duration:total_tick,duration_unit:duraSymbol,symbol:rnd}));
        }
        */
        tradeInProgress = true;
    }
    chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,
        theme: "light2",
        toolTip: {
            enabled: true,
            animationEnabled: true,
            borderColor: "#ccc",
            borderThickness: 1,
            fontColor: "#000",
            content: "{y}"
        },
        axisX: {
            includeZero: false,
            gridThickness: 0,
            titleFontSize: 0,
            labelFontSize: 0,
            tickLength: 0,
            lineThickness: 0
        },
        axisY: {
            stripLines: [{
                color: "red"
            }],
            includeZero: false,
            gridThickness: 0,
            titleFontSize: 0,
            labelFontSize: 0,
            tickLength: 0,
            lineThickness: 0
        },
        data: [{
                type: "line",
                lineColor: "gray",
                lineThickness: 2,
                dataPoints: dps
            }
            /*,{
            type: "line",
            lineThickness: 1,
            dataPoints: stripLinesTail
            },{
            type: "line",
            lineThickness: 1,
            dataPoints: stripLinesHead
            }*/
        ]
    });
    chart2 = new CanvasJS.Chart("chartContainer2", {
        animationEnabled: true,
        theme: "light2",
        exportEnabled: false,
        title: {
            titleFontSize: 0,
            text: ""
        },
        axisX: {
            gridThickness: 0,
            lineThickness: 1,
            tickLength: 0,
            labelFontSize: 0,
            labelFormatter: function(e) {
                return "test";
            }
        },
        axisY: {
            //stripLines: [{ color: "red" }],
            stripLines: [{
                color: "red"
            }],
            stripLines,
            gridThickness: 0,
            labelFontSize: 0,
            includeZero: false,
            title: ""
        },
        toolTip: {
            shared: true,
            content: " {x} <br> Open: {y[0]} <br> High: {y[1]}<br> Low: {y[2]}<br> Close: {y[3]} "
        },
        data: [{
            type: "candlestick",
            showInLegend: false,
            yValueFormatString: "###0.00",
            xValueFormatString: "hh:mm:ss",
            risingColor: "green",
            fallingColor: "red",
            dataPoints: dps2
        }]
    });
    chart3 = new CanvasJS.StockChart("chartContainer3", {
        title: {
            text: ""
        },
        animationEnabled: true,
        exportEnabled: false,
        rangeSelector: {
            enabled: false
        },
        charts: [{
            axisX: {
                crosshair: {
                    enabled: true,
                    snapToDataPoint: true,
                    lineDashType: "dashDot",
                    thickness: 1,
                    interval: 1
                },
                labelFontSize: 6,
                labelFormatter: function(e) {
                    let date = new Date(e.value);
                    let range = chart3.options.navigator.slider.maximum - chart3.options.navigator.slider.minimum;
                    let intervals = [
                        //{ max: 80000, interval: 2, intervalType: "second", format: { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false } },
                        //{ max: 80000, interval: 5, intervalType: "second", format: { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false } },
                        //{ max: 174000, interval: 15, intervalType: "second", format: { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false } },
                        {
                            max: 400000,
                            interval: 30,
                            intervalType: "second",
                            format: {
                                hour: "2-digit",
                                minute: "2-digit",
                                second: "2-digit",
                                hour12: false
                            }
                        },
                        {
                            max: 1176000,
                            interval: 1,
                            intervalType: "minute",
                            format: {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: false
                            }
                        },
                        {
                            max: 1820000,
                            interval: 2,
                            intervalType: "minute",
                            format: {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: false
                            }
                        },
                        {
                            max: 1992000,
                            interval: 5,
                            intervalType: "minute",
                            format: {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: false
                            }
                        }
                    ];
                    let selected = intervals.find(item => range <= item.max) || intervals[intervals.length - 1];
                    Object.assign(chart3.options.charts[0].axisX, {
                        interval: selected.interval,
                        intervalType: selected.intervalType
                    });
                    return date.toLocaleTimeString("en-GB", selected.format);
                }
                //,
                //interval: 30,
                //intervalType: "second",
            },
            axisY: {
                stripLines: [{
                    color: "red",
                    lineThickness: 1
                }],
                crosshair: {
                    enabled: true,
                    lineDashType: "dashDot", // Options: solid, dash, dot, dashDot
                    thickness: 1,
                    labelFontColor: "#2a3052",
                },
                labelFormatter: function(e) {
                    return e.value.toFixed(2);
                },
                labelFontSize: 9,
                labelFontWeight: "normal",
                gridThickness: 1,
                gridColor: "#e6e6e6",
                //gridDashType: "dot"
            },
            toolTip: {
                shared: true,
                borderThickness: 0,
                borderColor: null,
                contentFormatter: function(e) {
                    if (e.entries.length > 0) {
                        let dp = e.entries[0].dataPoint;
                        let date = new Date(dp.x);
                        let formattedDate = date.toLocaleString('en-GB', {
                            weekday: 'short',
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                            hour12: false
                        });
                        let indexName = rnd.replace("R_", "").replace("RD", "");
                        return `<div style="background:#d0d5d6;border: none;padding:5px;font-size:7px;">
                        <b>${formattedDate}</b><br/>
                        <label style="color:#5b898e">●</label>Volatility ${indexName} Index: <b>${dp.y.toFixed(2)}</b>
                        </div>`;
                    }
                }
            },
            data: [{
                type: "line",
                lineColor: "#5b898e",
                lineThickness: 1,
                dataPoints: dps3
            }]
        }],
        navigator: {
            backgroundColor: "white",
            borderThickness: 2,
            height: 20,
            slider: {
                minimum: new Date(currentDate.getTime() - (396 * 1000)),
                maximum: new Date(currentDate.getTime()),
                backgroundColor: "#5b898e",
                fillOpacity: 0.6
            },
            axisX: {
                labelFontColor: "black",
                labelFontSize: 8,
                interval: 10,
                intervalType: "minute",
                labelFormatter: function(e) {
                    let date = new Date(e.value);
                    return date.toLocaleTimeString('en-GB', {
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: false
                    });
                },
            }
        }
    });
}, false);




// ------------------ PATCHED EVENT LISTENERS ------------------
window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('addTokenBtn').addEventListener('click', () => {
        const token = document.getElementById('tokenInput').value.trim();
        if (!token) return;

        let tokens = JSON.parse(sessionStorage.getItem('tokens') || '[]');
        if (!tokens.some(t => t.token === token)) {
            tokens.push({ token, active: true, crAccount: '' });
            sessionStorage.setItem('tokens', JSON.stringify(tokens));
            renderTokenList();
        }
        document.getElementById('tokenInput').value = '';
    });

    function renderTokenList() {
        const tokenList = document.getElementById('tokenList');
        if (tokenList) {
            tokenList.innerHTML = ''; 
            const tokens = JSON.parse(sessionStorage.getItem('tokens') || '[]');
            tokens.forEach((t, i) => {
                const div = document.createElement('div');
                div.innerHTML = `
                    <input type="text" value="\${t.token}" data-index="\${i}" class="tokenField" style="width:300px">
                    <label><input type="checkbox" data-index="\${i}" class="activeToggle" \${t.active ? 'checked' : ''}> Active</label>
                    <span class="crAccountLabel">\${t.crAccount ? '(' + t.crAccount + ')' : ''}</span>
                `;
                tokenList.appendChild(div);
            });
        } else {
            //console.warn('[WARN] tokenList element not found — skipping render');
        }
    }

    document.getElementById('startSyncBtn').addEventListener('click', () => {
        const tokenFields = document.querySelectorAll('.tokenField');
        const toggles = document.querySelectorAll('.activeToggle');
        let tokens = [];
        tokenFields.forEach((input, i) => {
            tokens.push({
                token: input.value.trim(),
                active: toggles[i].checked,
                crAccount: '' // reset until sync
            });
        });
        sessionStorage.setItem('tokens', JSON.stringify(tokens));
        renderTokenList();
        //alert('Tokens saved and sync started');
    });

    // On page load
    document.addEventListener('DOMContentLoaded', () => {
        renderTokenList();
    });

});
